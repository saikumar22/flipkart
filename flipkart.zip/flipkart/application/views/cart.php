<style>
.cartview .theader {
    background: #2b5876;
    background: -webkit-linear-gradient(to right, #4e4376, #2b5876);
    background: linear-gradient(to right, #4e4376, #2b5876);
    height: 40px;
    color: white;
}

td,
h3 {
    color: black;
    padding: 10px;
}

.cartview {
    background-color: white;
}

footer {
    margin-top: 90px;
}
.btn-place{
    background: #fb641b;
    border-radius: 2px;
    color: white;
    text-align: center;
    font-weight: 500;
    font-size: 15px;
    outline: none;
    transition: 0.5s;
    margin-top: none;
    float: right;
}
</style>
<div class="container cartview" style="margin-top:80px">
    <h3>Your Cart</h3>
    <table border="2">
        <div class="container">
            <tr class="theader">
                <th width="15%">SNo.</th>
                <th width="10%">Image</th>
                <th width="30%">Product Name</th>
                <th width="15%">Price</th>
                <th width="20%">Quantity</th>
                <th width="15%">Total Price</th>
                <th width="5%">Remove</th>
            </tr>

            <?php 
			$i = 0;
			foreach ($cart as $cart) { 
            $a[$i] = $cart->total;

				$i++;
				?>
            <tr>
                <td><?php echo $i; ?></td>

                <td><?php
					 $pid = $cart->pid;
					 $row = $this->db->where("pid",$pid)->get("products")->result();?>
                    <img src="<?=base_url("products/").$row[0]->image;?>" alt="image" style="width: 50px;">

                </td>

                <td><?php
					 $pid = $cart->pid;
						echo ($row[0]->name);
					  ?></td>

                <td><?php
					 $pid = $cart->pid;
						echo ($row[0]->price);
					  ?></td>
                <td>
                    <form action="<?php echo base_url('home/update_cart'); ?>" method="post">
                        <input type="number" class="col-sm-7" name="quantity" value="<?php echo $cart->quantity ?>" />
                        <input type="hidden" name="price" value="<?php  $pid = $cart->pid; echo ($row[0]->price);?>">
                        <input type="hidden" name="cid" hidden value="<?php echo $cart->cid?>" />
                        <input type="submit" name="submit" value="Update" />
                    </form>
                </td>

                <td>Rs. <?php echo $cart->total;?></td>

                <td><a href="<?=base_url("home/remove/".$cart->cid)?>" class="btn btn-danger btn-sm">Remove</a></td>
            </tr>
            <?php } ?>
            <td colspan="7" style="border: 2px solid black;"> 
                <div class="" style="margin-left: 80%">
                    <?php echo "<h4>Grand Total - ".array_sum($a)."</h4>";?>
                </div>
            </td>
        </div>
    </table>
    <br>

    <a href="<?php echo site_url('home'); ?>" class="btn btn-primary">Continue Shopping</a>
    <a href="#" class="btn btn-place">PLACE ORDER</a>

</div>