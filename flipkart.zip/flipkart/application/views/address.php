<style>
.address {
    background-color: white;
}

.address .row {
    padding: 20px;
}

#addressform .row {
    padding: 10px;
}

.address .card {
    border: 1px solid black;
    list-style: none;
    padding: 20px;
}

.address .card .col-2 {
    float: right;
    margin-top: -50px;
}
.submit{
    text-align: center;
}
</style>
<div class="col-sm-8 address">
    <div class="row">
        <h3>Manage Addresses</h3>
        <div class="row">
            <a class=" btn-lg" data-toggle="modal" data-target="#addressform">Add a new
                address</a>
        </div>
        <?php foreach($address as $add){ ?>
        <div class="card">
            <div class="col-8">
                <li><?=$add->type;?></li>
                <li><?=$add->name;?> <?=$add->mobile;?> </li>
                <li><?=$add->address;?>, <?=$add->state;?>, <?=$add->pincode;?></li>
            </div>
            <div class="col-2">
                <form action="<?=base_url("home/addressdelete/").$add->address_id?>" method="post">
                    <input type="button" name="address_id" hidden value="<?=$add->address_id;?>">
                    <li><button type="submit" class="btn btn-danger btn-sm">Delete</button>
                    </li>
                </form>
            </div>
        </div>
        <?php }?>
    </div>
</div>
</div>
</div>
</div>

<div class="modal fade" id="addressform" role="dialog">
    <form action="<?php echo base_url();?>home/addressadd" method="post" enctype="multipart/form-data">
        <div class="modal-dialog">
      
            <div class="modal-content">
            <button type="button" class="close" data-dismiss="modal" style="margin-left: 20px;">&times;</button>
                <div class="modal-header">
                    ADD A NEW ADDRESS
                </div>
                <div class="modal-body">
                    <div class="row">
                        <input type="text" class="form-control" name="name" placeholder="Name">
                    </div>
                    <div class="row">
                        <input type="text" class="form-control" name="mobile" placeholder="Mobile">
                    </div>
                    <div class="row">
                        <input type="text" class="form-control" name="pincode" placeholder="Pincode">
                    </div>
                    <div class="row">
                        <input type="text" class="form-control" name="locality" placeholder="Locality">
                    </div>
                    <div class="row">
                        <textarea class="form-control" name="address" placeholder="Address"></textarea>
                    </div>
                    <div class="row">
                        <input type="text" class="form-control" name="city" placeholder="City/District/Town">
                    </div>
                    <div class="row">
                        <input type="text" class="form-control" name="state" placeholder="State">
                    </div>
                    <div class="row">
                        <input type="text" class="form-control" name="landmark" placeholder="Landmark (Optional)">
                    </div>
                    <div class="row">
                        <input type="text" class="form-control" name="alternate" placeholder="Alternate Phone">
                    </div>
                    <div class="row">
                        <label for="exampleFormControlInput1" class="form-label">Address Type:</label> <br>
                        <input type="radio" name="type" id="Home" value="Home">Home
                        <input type="radio" name="type" id="Work" value="Work"> Work <br>
                    </div>
                    <div class="row submit">
                        <input type="uid" name="uid" hidden value="<?=$this->session->uid?>">
                        <button type="submit" class="btn btn-danger" name="addressadd">Submit</button>
                    </div>
                </div>
            
            </div>
        </div>
    </form>
</div>