<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
        integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
        integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous" />
    <style>
    /* body {
        margin: 0;
        padding: 0;
        background: #000;
    }

    .box {
        border-radius: 3px;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        width: 750px;
        height: 560px;
        background: white;
        overflow: hidden;
    }

    .inline-text {
        color: white;
        position: absolute;
        top: 32px;
        left: 55px;

    }

    .inline-text h1 {
        font-size: 25px;
        margin-bottom: 20px;
    }

    .inline-text p {
        color: rgb(228, 228, 228);
        opacity: 0.9;
        font-size: 13px;
        letter-spacing: 1px;
    }

    .box1 {

        background: url(//img1a.flixcart.com/www/linchpin/fk-cp-zion/img/login_img_dec4bf.png);
        height: 100vh;
        background-position: center;
        background-repeat: no-repeat;
        background-color: #2874f0;
    }

    .box2 .user-id {
        position: relative;
        left: 20px;
        top: 50px;
        padding: 10px 20px;

    }

    .box2 .user-id input {
        width: 100%;
        height: 40px;


    }

    .box2 .user-data input {
      
        color: black;
        border: none;
        border-bottom: 1px solid rgb(228, 228, 228);
        outline: none;
        background: none;
        transition: 0.5s;
        margin-bottom: 20px;


    }

    .box2 .user-data label {
        color: rgb(158, 154, 154);
        padding: 10px 20px;
        position: absolute;
        ;
        top: 6px;
        left: 0;
        font-size: 18px;
        font-weight: 400;
        pointer-events: none;
        transition: 0.5s;

    }

    .box2 .user-data input:focus~label,
    .box2 .user-data input:valid~label {
        top: -20px;
        font-size: 12px;

    }

    .box2 .user-data input:focus {
        border-bottom: 1px solid #2874f0;
    }

    .box2 span a {
        position: absolute;
        top: 140px;
        left: 315px;
        display: inline;
        color: #2874f0;
        font-weight: 600;
    }

    .box2 .button input {
        height: 50px;
        font-size: 18px;
        border: none;
        background: #fff;

    }

    .user-id p {
        margin: 0;
        margin-left: 148px;
        color: rgb(173, 173, 173);
    }

    .box2 .button input[type=submit] {
        background: #fb641b;
        border-radius: 2px;
        color: white;
        font-weight: 500;
        font-size: 15px;
        outline: none;
        transition: 0.5s;
        margin-top: none;
    }

    .box2 .button input[type=reset] {
        box-shadow: 2px 1px 5px 0 rgba(0, 0, 0, 0.2);
        border-radius: 2px;
        color: #2874f0;
        font-weight: 600;
        outline: none;
        transition: 0.5s;
    }

    .box2 .button input[type=submit]:hover {
        box-shadow: 2px 3px 5px 0 rgba(0, 0, 0, 0.2);
    }

    .box2 .button input[type=reset]:hover {
        box-shadow: 2px 2px 10px 0 rgba(0, 0, 0, 0.2)
    }

    .user-id {
        position: absolute;
        font-weight: 600;
        text-decoration: none;
        color: #2874f0;
        margin-top: -15px;
    }
    .footer a{
    position: absolute;
    margin-top: 20px;
   margin-left: -70px;
    font-weight:600;
    text-decoration:none;
    color:#2874f0;
}

    .terms {
        margin-left: 50px;
        margin-top: 40px;
    } */
.login{
    background: #000;
}
    #login .col-sm-5 {
        background-color: #2874f0;
        color: white;
        margin-left: -17px;
    }

    #login .loginrow .col-sm-6 {
        padding: 20px;

    }

    #login .footer {
        padding: 20px;
        margin-top: 30px;
    }

    #login .user-id .btn-lg {
        background: #fb641b;
        border-radius: 2px;
        color: white;
        text-align: center;
        font-weight: 500;
        font-size: 15px;
        outline: none;
        transition: 0.5s;
        margin-top: none;
    }

    #login .inline-text-footer {
        margin-bottom: 100px;
        margin-top: 50px;
    }

    #login .user-id {
        text-align: center;
    }

    #login .close {
        color: white;
    }

    #login {
        padding: 60px;
    }

    #login .col-xs-6 {
        float: center;
    }

    .form-label {
        margin-top: 10px;
    }
    </style>
</head>

<body>
    <div class="login" id="login">
        <form action="<?= base_url('home/signup')?>" method="POST" enctype="multipart/form-data">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="row loginrow" style="background:white">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <div class="col-sm-5 col-xs-12 loginrow1">
                            <div class="inline-text">
                                <h1>Looks like you're new here!</h1>
                                <p>
                                    Sign up with your mobile<br />
                                    number to get started
                                </p>
                            </div>
                            <div class="inline-text-footer">
                                <img src="//img1a.flixcart.com/www/linchpin/fk-cp-zion/img/login_img_dec4bf.png" alt="">
                            </div>
                        </div>
                        <div class="col-sm-6 col-xs-12">
                            <div class="col-sm-12 col-xs-12">
                                <label for="exampleFormControlInput1" class="form-label">Name:</label>
                                <input type="text " name="name" class="form-control" required />
                            </div>
                            <div class="col-sm-12 col-xs-12">
                                <label for="exampleFormControlInput1" class="form-label">Email:</label>
                                <input type="email " name="email" class="form-control" required />
                            </div>
                            <div class="col-sm-12 col-xs-12">
                                <label for="exampleFormControlInput1" class="form-label">Password:</label>
                                <input type="password " name="password" class="form-control" required />
                            </div>
                            <div class="col-sm-12 col-xs-12">
                                <label for="exampleFormControlInput1" class="form-label">Mobile:</label>
                                <input type="number" name="mobile" class="form-control" required />
                            </div>

                            <div class="col-sm-12 col-xs-12">
                                <p>By continuing, you agree to Flipkart's <a href="">Terms of Use</a> and<a href="#">
                                        Privacy Policy.</p></a>
                            </div>
                            <div class="user-id button">
                                <input type="submit" name="signup" value="Sign Up" />
                            </div>

                            <div class="row">
                                <div class="user-id">
                                    <p class="footer"> <a href="<?= base_url('home/login')?>"
                                            value="Existing User? Log in">Existing User? Log
                                            in</a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>


    <!-- <div class="box">
            <div class="row">
                <div class="col-sm-5 col-md-5 box1">
                    <div class="inline-text">
                        <h1>Looks like you're new here!</h1>
                        <p>
                            Sign up with your mobile<br />
                            number to get started
                        </p>
                    </div>
                </div>
                <div class="col-sm-6 col-md-6 box2">
                    <div class="user">
                        <div class="user-id user-data">
                            <input type="name" name="name" required />
                            <label>Ente Name</label>
                        </div>
                        <div class="user-id user-data">
                            <input type="email" name="email" id="" required />
                            <label>Ente Email</label>
                        </div>
                        <div class="user-id user-data">
                            <input type="number" name="mobile" id="" required />
                            <label>Ente Mobile Number</label>
                        </div>
                        <div class="user-id user-data">
                            <input type="password" name="password" id="" required />
                            <label>Enter Password</label>
                        </div>
                        <div class="terms">
                            <p>By continuing, you agree to Flipkart's <a href="">Terms of Use</a> and<a href="#">
                                    Privacy Policy.</p></a>
                        </div>
                        <div class="user-id button">
                            <input type="submit" name="signup" value="Sign Up" />
                        </div>
                        <div class="user-id">
                            <p class="footer"> <a href="<?= base_url('home/login')?>" value="Existing User? Log in">Existing User? Log
                                in</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div> -->
</body>

</html>