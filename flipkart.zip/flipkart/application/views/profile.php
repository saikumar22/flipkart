<style>
    footer{
    margin-top: 30px;
}
</style>
<div class="col-sm-8 profile-edit" >
    <?php foreach ($users as $users) {  ?>
    <form action="<?= base_url('home/personalinfoupdate/'.$users->uid)?>" method="post" enctype="multipart/form-data">
        <div class="row">
            <h3>Personal Information</h3>
        </div>
        <div class="row">
            <label for="exampleFormControlInput1" class="form-label">Name:</label>
            <input type="text" class="form-control" name="name" value="<?= $users->name;?>">
        </div>
        <div class="row">
            <label for="exampleFormControlInput1" class="form-label">Your Gender:</label> <br>
            <input type="radio" name="gender" id="Male" value="Male" <?php if($users->gender=="Male"){ echo "checked"; }else{
                            }?>>Male
            <input type="radio" name="gender" id="Female" value="Female"
                <?php if($users->gender=="Female"){ echo "checked"; }?>> Female <br>
        </div>
        <div class="row">
            <h3>Email Address</h3>
            <input type="text" class="form-control" name="email" value="<?= $users->email;?>">
        </div>
        <div class="row">
            <h3>Mobile Number</h3>
            <input type="text" class="form-control" name="mobile" value="<?= $users->mobile;?>">
        </div>

        <div class="col-sm-12 nameupdate">
            <input type="uid" name="uid" hidden value="<?=$users->uid?>">
            <button type="submit" class="btn btn-danger" name="personalinfoupdate">Update</button>
        </div>
        <span style="color: blue; margin-top: -100px">
            <?php if($this->session->flashdata('status'));?>
            <?= $this->session->flashdata('status');?>
            <?php  ?>
        </span>
    </form>
    <div class="sub-details">
        <h3>FAQs</h3>
        <h4>What happens when I update my email address (or mobile number)?</h4>
        <p>Your login email id (or mobile number) changes, likewise. You'll receive all your account related
            communication on your updated email address (or mobile number).</p>
        <h4>When will my Flipkart account be updated with the new email address (or mobile number)?</h4>
        <p>It happens as soon as you confirm the verification code sent to your email (or mobile) and save the changes.
        </p>
        <h4>What happens to my existing Flipkart account when I update my email address (or mobile number)?</h4>
        <p>Updating your email address (or mobile number) doesn't invalidate your account. Your account remains fully
            functional. You'll continue seeing your Order history, saved information and personal details.</p>
        <h4>Does my Seller account get affected when I update my email address?</h4>
        <p>Flipkart has a 'single sign-on' policy. Any changes will reflect in your Seller account also.</p>
        <img src="<?=base_url('images/header/profile.png') ?>" alt="img">
    </div>
    <?php }?>
</div>
</div>
</div>
</div>