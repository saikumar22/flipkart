<style>
.title {
    text-align: center;
    color: black;
    font-weight: bold;
}
</style>
<div class="mens view-list">
    <div class="container-fluid">
        <div class="fashion-header">
            <h3><b>Men's Clothing</b></h3>
        </div>
        <div class="mobile-view" style="padding: 20px;">
            <div class="row">
                <div class="col-sm-4 col-lg-4 col-md-4">
                    <div class="card">
                        <a href="">
                            <div class="header common-col">
                                <img src="<?=base_url('/images/shirt/skyblue-dennis-lingo.jpeg')?>" class="mens1"
                                    alt="img">
                            </div><br>
                            <strong>Metronaut</strong>
                            <h5>Up to 10%</h5>
                            <p>shirt</p>
                        </a>
                    </div>
                </div>
                <div class="col-sm-4 col-lg-4 col-md-4">
                    <div class="card">
                        <a href="">
                            <div class="header common-col">
                                <img src="<?=base_url('/images/t-shirt/fine-white.jpeg')?>" class="mens1"
                                    alt="img" style="width: 35%;">
                            </div><br>
                            <strong>Metronaut</strong>
                            <h5>Up to 20%</h5>
                            <p>t-shirt</p>
                        </a>
                    </div>
                </div>
                <div class="col-sm-4 col-lg-4 col-md-4">
                    <div class="card">
                        <a href="">
                            <div class="header common-col">
                                <img src="<?=base_url('/images/shoes/white-blue.jpeg')?>" class="mens1"
                                    alt="img" style="width: 40%;">
                            </div><br>
                            <strong>bata</strong>
                            <h5>Up to 50%</h5>
                            <p>Shoes</p>
                        </a>
                    </div>
                </div>

                <div class="col-sm-4 col-lg-4 col-md-4">
                    <div class="card">
                        <a href="">
                            <div class="header common-col">
                                <img src="<?=base_url('/images/t-shirt/tripr-original.jpeg')?>" class="img"
                                    alt="img" style="width: 30%;">
                            </div><br>
                            <strong>Metronaut</strong>
                            <h5>Up to 10%</h5>
                            <p>shirt</p>
                        </a>
                    </div>
                </div>
                <div class="col-sm-4 col-lg-4 col-md-4">
                    <div class="card">
                        <a href="">
                            <div class="header common-col">
                                <img src="<?=base_url('/images/shirt/blue-base.jpeg')?>" class="img"
                                    alt="img">
                            </div><br>
                            <strong>Metronaut</strong>
                            <h5>Up to 10%</h5>
                            <p>shirt</p>
                        </a>
                    </div>
                </div>
                <div class="col-sm-4 col-lg-4 col-md-4">
                    <div class="card">
                        <a href="">
                            <div class="header common-col">
                                <img src="<?=base_url('/images/pants/bmw-cotton.jpeg')?>" class="img"
                                    alt="img">
                            </div><br>
                            <strong>cotton</strong>
                            <h5>Up to 10%</h5>
                            <p>shirt</p>
                        </a>
                    </div>
                </div>

                <div class="col-sm-4 col-lg-4 col-md-4">
                    <div class="card">
                        <a href="">
                            <div class="header common-col">
                                <img src="<?=base_url('/images/shirt/textiles-original.jpeg')?>" class="img"
                                    alt="img" style="width: 30%;">
                            </div><br>
                            <strong>textiles</strong>
                            <h5>Up to 10%</h5>
                            <p>shirt</p>
                        </a>
                    </div>
                </div>
                <div class="col-sm-4 col-lg-4 col-md-4">
                    <div class="card">
                        <a href="">
                            <div class="header common-col">
                                <img src="<?=base_url('/images/shirt/lawful-casual.jpeg')?>" class="img"
                                    alt="img">
                            </div><br>
                            <strong>casual</strong>
                            <h5>Up to 10%</h5>
                            <p>shirt</p>
                        </a>
                    </div>
                </div>
                <div class="col-sm-4 col-lg-4 col-md-4">
                    <div class="card">
                        <a href="">
                            <div class="header common-col">
                                <img src="<?=base_url('/images/shirt/raymond.jpeg')?>" class="img"
                                    alt="img" style="width: 30%;">
                            </div><br>
                            <strong>raymond</strong>
                            <h5>Up to 10%</h5>
                            <p>shirt</p>
                        </a>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>