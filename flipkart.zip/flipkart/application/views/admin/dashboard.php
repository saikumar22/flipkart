<div class="container-fluid dashboard">
    <div class="row" id="display">
        <div class="col-md">
            <table class="table">
                <div>
                    <h4><b>List of Products</b></h4>
                    <h6 colspan="5" align="right" style="margin-top: -40px"><a href="<?=base_url("admin/add_product")?>"
                            class="btn btn-success btn-sm">Add Product</a></h6>
                </div>
                <div class="view">
                    <theader>
                        <tr class="theader" id="view">
                            <td>Id</td>
                            <td>Name</td>
                            <td>price</td>
                            <td>Category Name</td>
                            <td>Model Name</td>
                            <td>Date of created</td>
                            <td>View</td>
                            <td>Edit</td>
                            <td>Delete</td>
                        </tr>
                    </theader>
                    <tbody>
                        <?php 	$i = 0;
                         foreach ($products as $products => $rg):
                            $i++;
                            ?>
                         
                            <tr>
                                <td><?= $i ?></td>
                                <td><?php echo $rg->name?></td>
                                <td><?php echo $rg->price;?></td>
                                <td><?php echo $rg->categoryname?></td>
                                <td><?php echo $rg->modelname?></td>
                                <td><?php echo $rg->date_created;?></td>
                                <td><a href="<?=base_url("admin/View/".$rg->pid)?>"class="btn btn-success btn-sm">view</a></td>
                                <td><a href="<?=base_url("admin/product_edit/".$rg->pid)?>"class="btn btn-primary btn-sm">Edit</a></td>
                                <td><a href="<?=base_url("admin/product_delete/".$rg->pid)?>"class="btn btn-danger btn-sm">Delete</a></td>
                            </tr>
                            <?php endforeach; $i++; ?>
                    </tbody>
                </div>
        </div>
    </div>
</div>