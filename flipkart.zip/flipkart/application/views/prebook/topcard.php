<style>
    .title{
    text-align: center;
    color: black;
    font-weight: bold;
}
</style>
<div class="viewcard view-list">
    <div class="container-fluid">
        <div class="fashion-header">
            <h3><b>Top Offers</b></h3>
        </div>
        <div class="mobile-view" style="padding: 20px;">
            <div class="row">
                <div class="col-sm-4 col-lg-4 col-md-4">
                    <div class="card">
                        <a href="<?=base_url('home/productview')?>">
                            <div class="header common-col">
                                <img src="<?=base_url('/images/viewcard/img2.jpeg')?>" class="img"
                                    alt="img" style="width: 30%;">
                            </div>
                            <div class="title">Childen’s Books</div >
                            <h5>up to 65%</h5>
                            <p>Action And Adventure Books</p>
                        </a>
                    </div>
                </div>
                <div class="col-sm-4 col-lg-4 col-md-4">
                    <div class="card">
                        <a href="">
                            <div class="header common-col">
                                <img src="<?=base_url('/images/viewcard/img3.jpeg')?>" class="img" alt="img" style="width: 30%;">
                            </div>
                            <div class="title">Business Books</div >
                            <h5>up to 60%</h5>
                            <p>Peter Lynch, Sudhir Dixit & More</p>
                        </a>
                    </div>
                </div>
                <div class="col-sm-4 col-lg-4 col-md-4">
                    <div class="card">
                        <a href="">
                            <div class="header common-col">
                                <img src="<?=base_url('/images/viewcard/img4.jpeg')?>" class="img" alt="img" style="width: 30%;">
                            </div>
                            <div class="title">Biographies</div >
                            <h5>up to 15%</h5>
                            <p>A P J Abdul Kalam, Ann Frank</p>
                        </a>
                    </div>
                </div>

                <div class="col-sm-4 col-lg-4 col-md-4">
                    <div class="card">
                        <a href="">
                            <div class="header common-col">
                                <img src="<?=base_url('/images/viewcard/img5.jpeg')?>" class="img"
                                    alt="img" style="width: 30%;">
                            </div>
                            <div class="title">Literature Books</div >
                            <h5>up to 65%</h5>
                            <p>Ramachandra Guha, Mark Twain</p>
                        </a>
                    </div>
                </div>
                <div class="col-sm-4 col-lg-4 col-md-4">
                    <div class="card">
                        <a href="">
                            <div class="header common-col">
                                <img src="<?=base_url('/images/viewcard/img6.jpeg')?>" class="img" alt="img" style="width: 30%;">
                            </div>
                            <div class="title">Magbook Indian Economy 2021</div >
                            <h5>up to 65%</h5>
                            <p>Rs.15999</p>
                        </a>
                    </div>
                </div>
                <div class="col-sm-4 col-lg-4 col-md-4">
                    <div class="card">
                        <a href="">
                            <div class="header common-col">
                                <img src="<?=base_url('/images/viewcard/img7.jpeg')?>" class="img"
                                    alt="img" style="width: 30%;">
                            </div>
                            <div class="title">Pre-Orders</div >
                            <h5>up tp 10%</h5>
                            <p>Explore now!</p>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>