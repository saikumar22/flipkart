<style>
.header-row {
    text-align: center;
    color: #5182a7;
    font-size: 120%;
}

.row {
    text-align: left;
    color: #e78217;
    font-size: 16px;
}

</style>
<div class="container addproduct">
    <div class="row" id="display">
        <section class="add-product">
            <div class='col-xs-12 col-sm-12 col-md-12 col-lg-12 row'>
                <div class="col-xs-0 col-sm-2 col-md-3 col-lg-3"></div>
                <div class="col-xs-12 col-sm-8 col-md-6 col-lg-6">
                    <div class="form">
                        <h3>ADD PRODUCT</h3>
                        <form class="Add-product" name="Add-product" method='post'
                            action='<?php echo base_url();?>admin/addproduct' enctype="multipart/form-data">
                            <div class="form-group row">
                                <p>Name:</p>
                                <input type="text" name='name' class='form-control' placeholder="Product Name"
                                    required />
                            </div>
                            <div class="form-group row">
                                <p>Image:</p>
                                <input type="file" class='form-control' name="image" required>
                            </div>
                            <div class="form-group row">
                                <p>Rs:</p>
                                <input type="text" name='price' class='form-control' placeholder="Product price"
                                    required />
                            </div>
                            <div class="form-group row">
                                <p>Watch Price:</p>
                                <input type="text" name='aprice' class='form-control' placeholder="Product watch price"
                                    required />
                            </div>

                            <div class="form-group row">
                                <p>Storage:</p>
                                <select name="storage" class="form-control" placeholder="storage">
                                    <option value="" disabled selected hidden></option>
                                    <option value="64GB" name="64GB">64GB</option>
                                    <option value="128GB" name="128GB">128GB</option>
                                </select>
                            </div>
                            <div class="form-group row">
                                <p>RAM:</p>
                                <select name="ram" class="form-control" placeholder="ram">
                                    <option value="" disabled selected hidden></option>
                                    <option value="4GB" name="4GB">4GB</option>
                                    <option value="6GB" name="6GB">6GB</option>
                                    <option value="8GB" name="8GB">8GB</option>
                                </select>
                            </div>

                            <div class="form-group row">
                                <p>Highlights:</p>
                                <textarea name='highlights' class='form-control'
                                    placeholder="Enter Products Highlights's" required></textarea>
                            </div>

                            <div class="form-group row">
                                <p>Description:</p>
                                <textarea name='description' class='form-control'
                                    placeholder="Enter Products Description" required></textarea>
                            </div>
                            <div class="form-group row">
                                <p>Description 1:</p>
                                <textarea name='des_1' class='form-control' placeholder="Enter Products Description"
                                    required></textarea>
                            </div>
                            <!-- <div class="form-group row">
                                <p>Image 1:</p>
                                <input type="file" name='des_img1' class='form-control' required />
                            </div> -->
                            <div class="form-group row">
                                <p>Description 2:</p>
                                <textarea name='des_2' class='form-control' placeholder="Enter Products Description"
                                    required></textarea>
                            </div>
                            <!-- <div class="form-group row">
                                <p>Image 2:</p>
                                <input type="file" name='des_img2' class='form-control' required />
                            </div> -->

                            <div class="form-group row">
                                <p>General:</p>
                                <input name='general' class='form-control' placeholder="Enter In The Box"
                                    required></input>
                            </div>
                            <div class="form-group row">
                                <p>Model Number:</p>
                                <input name='modelnumber' class='form-control' placeholder="Model Number"
                                    required></input>
                            </div>

                            <div class="form-group row">
                                <p>Model Name:</p>
                                <input name='modelname' class='form-control' placeholder="Model Name"
                                    required></input>
                            </div>

                            <div class="form-group row">
                                <p>Color:</p>
                                <input type="text" name='color' class='form-control' placeholder="Color" required />
                            </div>

                            <div class="form-group row">
                                <p>Browse Type:</p>
                                <input type="text" name='browsetype' class='form-control' placeholder="Browse Type"
                                    required />
                            </div>

                            <div class="form-group row">
                                <p> Category Name</p>
                                <input type="text" name='categoryname' class='datepicker form-control'
                                    placeholder="Category name" required />
                            </div>
                            <div class="form-group row">
                                <p>Date of created:</p>
                                <input type="date" name='date_created' class='form-control' placeholder="Browse Type"
                                    required />
                            </div>
                            <div>
                                <button type="submit" class="btn btn-danger" name="addproduct">SUBMIT</button>
                            </div>
                    </div>
                </div>
            </div>
        </section>

    </div>
</div>