<style>
.theader th{
    height: 30px;
}
</style>
<div class="container-fluid dashboard">
    <div class="row" id="display">
        <div class="col-md">
            <table class="table">
                <div class="view">
                    <theader>
                        <tr class="theader" id="view">
                            <th style="height: 30px;">Id</th>
                            <th>User name</th>
                            <th>Image</th>
                            <th>Product Name</th>
                            <th>price</th>
                            <th>Quantity</th>
                            <th>Total</th>
                            <th>Category Name</th>
                            <th>Model Name</th>
                            <th>Date</th>

                        </tr>
                    </theader>
                    <tbody>
                        <?php 	$i = 0;
                         foreach ($cart as $cart => $rg):
                            $i++;
                            ?>

                        <tr>
                            <td><?= $i ?></td>

                            <td><?php
                                $uid = $rg->uid;
                                $row = $this->db->where("uid",$uid)->get("users")->result();
                                echo ($row[0]->name);?>
                            </td>

                            <td><?php
                                $pid = $rg->pid;
                                $row = $this->db->where("pid",$pid)->get("products")->result();?>
                                <img src="<?=base_url("products/".$row[0]->image);?>" alt="image" style="width: 50px;">
                            </td>

                            <td><?php echo $rg->name;?></td>
                            <td><?php echo $rg->price;?></td>
                            <td><?php echo $rg->quantity;?></td>
                            <td>
                                <?php echo $rg->total;?>
                            </td>
                            <td><?php
                                $pid = $rg->pid;
                                $row = $this->db->where("pid",$pid)->get("products")->result();
                                echo ($row[0]->categoryname);?>
                            </td>
                            <td><?php
                                $pid = $rg->pid;
                                $row = $this->db->where("pid",$pid)->get("products")->result();
                                echo ($row[0]->modelname);?>
                            </td>
                            <td><?php echo $rg->date;?></td>
                        </tr>
                        <?php endforeach; $i++; ?>
                    </tbody>
                </div>
        </div>
    </div>
</div>