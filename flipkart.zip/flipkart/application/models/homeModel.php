<?php
class homeModel extends CI_Model {
public function __construct(){
$this->load->database('default');
$this->load->library('session');
}
public function delete($address_id){
    return $this->db->delete("address", ['address_id'=>$address_id]);
}
public function get_product_by_id($pid){
    $this->db->select('*');
    $this->db->from('products');
    // $this->db->order_by('products.pid', 'DESC');
    $this->db->where('products.pid', $pid);
    $info = $this->db->get();
    return $info->row();
}
public function removetocart($cid){
    return $this->db->delete("cart", ['cid'=>$cid]);
}
}