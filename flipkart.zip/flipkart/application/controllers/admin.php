<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class admin extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->helper('url');
        $this->load->model('adminModel');
        $this->load->library(array('form_validation','session'));
    }
    public function  index(){
        $this->load->view("admin/adminheader");
        $this->load->view("admin/sidemenu");
        $data['products'] =$this->db->get("products")->result();
        $this->load->view("admin/dashboard",$data);
    }
    public function users(){
        $this->load->view("admin/adminheader");
        $this->load->view("admin/sidemenu");
        $data['users'] =$this->db->where("role!=","1")->get("users")->result();
        $this->load->view("admin/userdetails",$data);
    }
    public function add_product(){
        $this->load->view("admin/adminheader");
        $this->load->view("admin/sidemenu");
        $this->load->view("admin/addproduct");
    }
    public function addproduct(){
        $this->load->helper('file');

        $config['upload_path']   = './products/';
        $config['allowed_types'] = 'gif|jpeg|jpg|png|pdf';
        $config['max_size']      = 10240;
        $this->load->library('upload', $config);
    
        if($this->upload->do_upload('image'))
        {
            $this->upload->data("file_name");
            
            $data = [
                'name' => $this->input->post('name'),
                'image'=>$this->upload->data("file_name"),
                'price' => $this->input->post('price'),
                'aprice' =>$this->input->post('aprice'),
                'storage' =>$this->input->post('storage'),
                'highlights' =>$this->input->post('highlights'),
                'description' =>$this->input->post('description'),
                'des_1'=>$this->input->post('des_1'),
                // 'des_img1' =>$this->input->post('des_img1'),
                'des_2' =>$this->input->post('des_2'),
                // 'des_img2' =>$this->input->post('des_img2'),
                'general' =>$this->input->post('general'),
                'modelnumber'=>$this->input->post('modelnumber'),
                "modelname" => $this->input->post('modelname'),
                'color' =>$this->input->post('color'),
                'browsetype'=>$this->input->post('browsetype'),
                "categoryname" => $this->input->post('categoryname'),
                'date_created' => date('Y-m-d H:i:s')
            ];

        $product = $this->db->insert("products",$data);
        redirect(base_url('admin'));
                } 
        else
        {
            echo  $this->upload->display_errors();
        }
    
    }
    

    public function product_edit($pid){
        $this->load->view("admin/adminheader");
        $this->load->view("admin/sidemenu");
        $data['products'] =$this->db->where('pid',$pid)->get("products")->result();
        $this->load->view("admin/editproduct",$data);
    }

    public function product_update($pid){
        $this->load->helper('file');
        $config['upload_path']   = './products/';
        $config['allowed_types'] = 'gif|jpeg|jpg|png|pdf';
        $config['max_size']      = 10240;
        $this->load->library('upload', $config);

        if($this->upload->do_upload('image'))
        {
            $this->upload->data("file_name");
        }else{
            	$this->upload->display_errors();
            }
            $data=[    
                "image"=>  $this->upload->data("file_name"),
                'name' => $this->input->post('name'),
                'price' => $this->input->post('price'),
                'aprice' =>$this->input->post('aprice'),
                'storage' =>$this->input->post('storage'),
                'highlights' =>$this->input->post('highlights'),
                'description' =>$this->input->post('description'),
                'des_1'=>$this->input->post('des_1'),
                // 'des_img1' =>$this->input->post('des_img1'),
                'des_2' =>$this->input->post('des_2'),
                // 'des_img2' =>$this->input->post('des_img2'),
                'general' =>$this->input->post('general'),
                'modelnumber'=>$this->input->post('modelnumber'),
                "modelname" => $this->input->post('modelname'),
                'color' =>$this->input->post('color'),
                'browsetype'=>$this->input->post('browsetype'),
                "categoryname" => $this->input->post('categoryname'),
                'date_created' => date('Y-m-d H:i:s')
            ];
            $admin = new adminModel;
            $res = $admin->updateJob($data, $pid);
            $this->session->set_flashdata('status','Profile Update Successfully');
            redirect(base_url('admin/product_edit/'.$pid));
    }
    


    public function View($pid){
        $this->load->view("admin/adminheader");
        $this->load->view("admin/sidemenu");
        $data['products'] =$this->db->where('pid',$pid)->get("products")->result();
        $this->load->view("admin/product-view",$data);
    }
    public function product_delete($pid){
        $delete= $this->adminModel->delete($pid);
            if ($delete) {
                redirect(base_url("admin")); 
                echo "success";      
            }else{
                echo "unable to delete";
            }

    }
    public function cart(){
        $this->load->view("admin/adminheader");
        $this->load->view("admin/sidemenu");
        $result['products'] = $this->db->get("products")->result();
        $result['cart'] = $this->db->get("cart")->result();
        $this->load->view('admin/cartview',$result);
    }
    
}