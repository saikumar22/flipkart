<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!--Bootstrap 3  -->
    <link rel="stylesheet" href="<?= base_url("/assets/bootstrap-3.3.7-dist/css/bootstrap.min.css")?>">
    <script src="<?= base_url("/assets/bootstrap-3.3.7-dist/js/bootstrap.min.js")?>"></script>

    <!-- Flickity -->
    <link rel="stylesheet" href="<?= base_url("/assets/flickity-docs/css/font-awesome.min.css")?>">
    <link rel="stylesheet" href="<?= base_url("/assets/flickity-docs/flickity.min.css")?>">
    <script src="<?= base_url("/assets/flickity-docs/flickity.pkgd.min.js")?>"></script>

    <!-- View All css -->
    <link rel="stylesheet" href="<?= base_url("/assets/css/viewall.css")?>">
    <link rel="stylesheet" href="<?= base_url("/assets/css/home.css")?>">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- icons -->
    <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">

    <!--jQuery library-->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

    <!--Latest compiled and minified JavaScript-->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


    <title>Flipkart</title>
</head>

<style>
body {
    background-color: #f1f3f6;
}

.header-left {
    text-align: right;
    margin: -15px -10px;
    font: Roboto, Arial, sans-serif;
    font-size: 20px;

}

.header-left a {
    color: white;
    font-size: 20px;
    text-decoration: none;
    font-weight: bold;
    font-style: italic;
}

.header-left-p {
    margin: -6px -3px 0px 0px;
}

.header-left-p a {
    font-size: 10px;
    font-style: italic;

}

.header-left-p span {
    color: yellow;
    font-size: 10px;
}

.header-left-p:hover {
    text-decoration: underline;
    color: white;
}

/* --------------------------------------------- footer -- */
footer {
    background-color: #172337;

}

footer .container-fluid {
    background-color: #172337;
    padding-top: 20px;
}

.footer-row {
    padding-left: 40px;
}

.footer-heading p {
    color: #878787;
    font-size: 12px;
    font-weight: 400;
    text-align: left;
    padding: 10px 0px;
    cursor: pointer;
    text-transform: uppercase;
}

.footer-list a {
    text-align: left;
    display: block;
    text-decoration: none;
    text-transform: capitalize;
    color: white;
    font-size: 12px;
    font-weight: 400;
    padding: 3px 0px;
}

.footer-list a:hover {
    text-decoration: underline;
}

.footer-list p {
    text-align: left;
    display: block;
    color: white;
    font-size: 12px;
    font-weight: 100px;
    padding: 5px 0px;
    line-height: 20px;
    cursor: pointer;
}

.footer-list-address p {
    text-align: left;
    display: block;
    color: white;
    font-size: 12px;
    font-weight: 100px;
    line-height: 10px;
    cursor: pointer;
}

.footer-list-address span {
    color: rgb(60, 109, 245);
    cursor: pointer;
}

.sub-footer p {
    color: white;
    font-size: 15px;
    font-weight: 100px;
    line-height: 20px;
    cursor: pointer;
    text-align: center;
    line-height: 50px;
    letter-spacing: .7px;
}

.fa-shopping-bag,
.fa-star,
.fa-gift,
.fa-question-circle {
    color: #ffd700;
    cursor: pointer;
    padding-right: 10px;
    font-size: 15px;
}

.sub-footer .img {
    width: 90%;
}
</style>