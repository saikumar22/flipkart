<style>
.header-row {
    text-align: center;
    color: #5182a7;
    font-size: 120%;
}

.row {
    text-align: left;
    color: #e78217;
    font-size: 16px;
}
</style>
<div class="container addproduct">
    <div class="row" id="display">
        <section class="add-product">
            <?php foreach ($products as $product): ?>
            <div class='col-xs-12 col-sm-12 col-md-12 col-lg-12 row'>
                <div class="col-xs-0 col-sm-2 col-md-3 col-lg-3">
                </div>
                <div class="col-xs-12 col-sm-8 col-md-6 col-lg-6">
                    <h3>EDIT PRODUCT</h3>

                    <div class="form">
                        <div class="row">
                            <?php if($this->session->flashdata('status'));?>
                            <div class="alert alert-success" style="background: white; border: 0px solid white;">
                                <?= $this->session->flashdata('status');?>
                            </div>
                            <?php  ?>
                        </div>

                        <form method='post' action='<?php echo base_url("admin/product_update/".$product->pid)?>'
                            enctype="multipart/form-data">
                            <div class="form-group row">
                                <p>Name:</p>
                                <input type="text" name='name' class='form-control' placeholder="Product Name"
                                    value="<?=$product->name?>" required />
                            </div>
                            <div class="form-group row">
                                <p>Image:</p>
                                <input type="file" name="image" multiple>
                                <img src="<?=base_url('products/'.$product->image) ?>" alt="" style="width: 10%; padding:5px">
                            </div>
                            <div class="form-group row">
                                <p>Rs:</p>
                                <input type="text" name='price' class='form-control' placeholder="Product price"
                                    value="<?=$product->price?>" required />
                            </div>
                            <div class="form-group row">
                                <p>Watch Price:</p>
                                <input type="text" name='aprice' class='form-control' placeholder="Product watch price"
                                    value="<?=$product->aprice?>" required />
                            </div>

                            <div class="form-group row">
                                <p>Storage:</p>
                                <select name="storage" class="form-control" placeholder="storage">
                                    <option value="" disabled selected hidden></option>
                                    <option value="64GB" name="64GB"
                                        <?php if($product->storage=="64GB"){echo "selected";}?>>64GB</option>
                                    <option value="128GB" name="128GB"
                                        <?php if($product->storage=="128GB"){echo "selected";}?>>128GB</option>
                                </select>
                            </div>
                            <div class="form-group row">
                                <p>RAM:</p>
                                <select name="ram" class="form-control" placeholder="ram">
                                    <option value="" disabled selected hidden></option>
                                    <option value="4GB" name="4GB" <?php if($product->ram=="4GB"){echo "selected";}?>>
                                        4GB</option>
                                    <option value="6GB" name="6GB" <?php if($product->ram=="6GB"){echo "selected";}?>>
                                        6GB</option>
                                    <option value="8GB" name="8GB" <?php if($product->ram=="8GB"){echo "selected";}?>>
                                        8GB</option>
                                </select>
                            </div>

                            <div class="form-group row">
                                <p>Highlights:</p>
                                <textarea name='highlights' class='form-control'
                                    placeholder="Enter Products Highlights's"
                                    required><?=$product->highlights?></textarea>
                            </div>

                            <div class="form-group row">
                                <p>Description:</p>
                                <textarea name='description' class='form-control'
                                    placeholder="Enter Products Description"
                                    required><?=$product->description?></textarea>
                            </div>
                            <div class="form-group row">
                                <p>Description 1:</p>
                                <textarea name='des_1' class='form-control' placeholder="Enter Products Description"
                                    required><?=$product->des_1?></textarea>
                            </div>
                            <!-- <div class="form-group row">
                                <p>Image 1:</p>
                                <input type="file" name='des_img1' class='form-control' required />
                            </div> -->
                            <div class="form-group row">
                                <p>Description 2:</p>
                                <textarea name='des_2' class='form-control' placeholder="Enter Products Description"
                                    required><?=$product->des_2?></textarea>
                            </div>
                            <!-- <div class="form-group row">
                                <p>Image 2:</p>
                                <input type="file" name='des_img2' class='form-control' required />
                            </div> -->

                            <div class="form-group row">
                                <p>General:</p>
                                <input name='general' class='form-control' placeholder="Enter In The Box"
                                    value="<?=$product->general?>" required></input>
                            </div>
                            <div class="form-group row">
                                <p>Model Number:</p>
                                <input name='modelnumber' class='form-control' placeholder="Model Number"
                                    value="<?=$product->modelnumber?>" required></input>
                            </div>

                            <div class="form-group row">
                                <p>Model Name:</p>
                                <input name='modelname' class='form-control' placeholder="Model Name"
                                    value="<?=$product->modelname?>" required></input>
                            </div>

                            <div class="form-group row">
                                <p>Color:</p>
                                <input type="text" name='color' class='form-control' placeholder="Color"
                                    value="<?=$product->color?>" required />
                            </div>

                            <div class="form-group row">
                                <p>Browse Type:</p>
                                <input type="text" name='browsetype' class='form-control' placeholder="Browse Type"
                                    value="<?=$product->browsetype?>" required />
                            </div>

                            <div class="form-group row">
                                <p> Category Name</p>
                                <input type="text" name='categoryname' class='datepicker form-control'
                                    value="<?=$product->categoryname?>" placeholder="Category name" required />
                            </div>
                            <div class="form-group row">
                                <p>Date of created:</p>
                                <input type="date" name='date_created' class='form-control'
                                    value="<?=$product->date_created;?>" required />
                            </div>
                            <div>
                                <button type="submit" class="btn btn-danger" name="product_update">Update</button>
                            </div>
                    </div>
                </div>
            </div>
            <?php endforeach;?>
        </section>

    </div>
</div>