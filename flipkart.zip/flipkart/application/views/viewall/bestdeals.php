<style>
.title {
    text-align: center;
    color: black;
    font-weight: bold;
}

.header .best {
    width: 50%;
}
</style>
<div class="mens view-list">
    <div class="container-fluid">
        <div class="fashion-header">
            <h3><b>Best Price On Fashion</b></h3>
        </div>
        <div class="mobile-view" style="padding: 20px;">
            <div class="row">
                <div class="col-sm-4 col-lg-4 col-md-4">
                    <div class="card col-xs-12">
                        <a href="">
                            <div class="header common-col">
                                <img src="<?=base_url('/images/fashion/shirt.jpeg')?>" class="best" alt="img"
                                    style="width: 35%;" style="width: 35%;">
                            </div>
                            <strong>Denim shirt</strong>
                            <h5>Min 60% off</h5>
                            <p>T-Shirts</p>
                        </a>
                    </div>
                </div>
                <div class="col-sm-4 col-lg-4 col-md-4">
                    <div class="card col-xs-12">
                        <a href="">
                            <div class="header common-col">
                                <img src="<?=base_url('/images/fashion/wallet.jpeg')?>" class="best" alt="img"
                                    style="width: 35%;">
                            </div>
                            <strong>Men Wallet</strong>
                            <h5>Min 30% off</h5>
                            <p>wallets</p>
                        </a>
                    </div>
                </div>
                <div class="col-sm-4 col-lg-4 col-md-4">
                    <div class="card col-xs-12">
                        <a href="">
                            <div class="header common-col">
                                <img src="<?=base_url('/images/fashion/saree.jpeg')?>" class="best" alt="img"
                                    style="width: 35%;">
                            </div>
                            <strong>Saree</strong>
                            <h5>Min 50% off</h5>
                            <p>Saree</p>
                        </a>
                    </div>
                </div>

                <div class="col-sm-4 col-lg-4 col-md-4">
                    <div class="card col-xs-12">
                        <a href="">
                            <div class="header common-col">
                                <img src="<?=base_url('/images/fashion/woodland-footware.jpeg')?>" class="best"
                                    alt="img" style="width: 35%;">
                            </div>
                            <strong>Woodland</strong>
                            <h5>Min 60% off</h5>
                            <p>Footware</p>
                        </a>
                    </div>
                </div>
                <div class="col-sm-4 col-lg-4 col-md-4">
                    <div class="card col-xs-12">
                        <a href="">
                            <div class="header common-col">
                                <img src="<?=base_url('/images/fashion/shirt1.jpeg')?>" class="best" alt="img"
                                    style="width: 35%;">
                            </div>
                            <strong>Denim shirt</strong>
                            <h5>Min 60% off</h5>
                            <p>T-Shirts</p>
                        </a>
                    </div>
                </div>
                <div class="col-sm-4 col-lg-4 col-md-4">
                    <div class="card col-xs-12">
                        <a href="">
                            <div class="header common-col">
                                <img src="<?=base_url('/images/fashion/shoes.jpeg')?>" class="best" alt="img"
                                    style="width: 35%;">
                            </div>
                            <strong>Sparx-footware</strong>
                            <h5>Min 20% off</h5>
                            <p>Shoes</p>
                        </a>
                    </div>
                </div>

                <div class="col-sm-4 col-lg-4 col-md-4">
                    <div class="card col-xs-12">
                        <a href="">
                            <div class="header common-col">
                                <img src="<?=base_url('/images/fashion/wallet-ladys.jpeg')?>" class="best" alt="img"
                                    style="width: 35%;">
                            </div>
                            <strong>Wallet Ladys</strong>
                            <h5>Min 60% off</h5>
                            <p>Wallet</p>
                        </a>
                    </div>
                </div>
                <div class="col-sm-4 col-lg-4 col-md-4">
                    <div class="card col-xs-12">
                        <a href="">
                            <div class="header common-col">
                                <img src="<?=base_url('/images/fashion/footware.jpeg')?>" class="best" alt="img"
                                    style="width: 35%;">
                            </div>
                            <strong>Footware</strong>
                            <h5>Min 60% off</h5>
                            <p>mens footware</p>
                        </a>
                    </div>
                </div>
                <div class="col-sm-4 col-lg-4 col-md-4">
                    <div class="card">
                        <a href="">
                            <div class="header common-col">
                                <img src="<?=base_url('/images/shirt/raymond.jpeg')?>" class="best" alt="img"
                                    style="width: 35%;" style="width: 30%;">
                            </div><br>
                            <strong>raymond</strong>
                            <h5>Up to 10%</h5>
                            <p>shirt</p>
                        </a>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>