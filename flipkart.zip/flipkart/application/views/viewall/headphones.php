<style>
    .title{
        text-align: center;
        color: black;
        font-weight: bold;
    }
</style>
<div class="headphones view-list">
    <div class="container-fluid">
        <div class="fashion-header">
            <h3><b>Best selling Phones</b></h3>
        </div>
        <div class="mobile-view">
            <div class="row">
                <div class="col-sm-4 col-lg-4 col-md-4">
                    <div class="card">
                        <a href="">
                            <div class="header common-col">
                                <img src="<?=base_url('/images/headphones/airbass-combuds.jpeg')?>" class="img"
                                    alt="img" style="width: 40%;">
                            </div>
                            <div class="title">boAt audio AirBass Bluetooth</div>
                            <h5>₹ 1,499</h5>
                        </a>
                    </div>
                </div>
                <div class="col-sm-4 col-lg-4 col-md-4">
                    <div class="card">
                        <a href="">
                            <div class="header common-col">
                                <img src="<?=base_url('/images/headphones/airdopes.jpeg')?>" class="img" alt="image" style="width: 50%;">
                            </div>
                            <div class="title">boAt Airdoes 131 Bluetooth</div>
                            <h5>₹ 1,299</h5>
                        </a>
                    </div>
                </div>
                <div class="col-sm-4 col-lg-4 col-md-4">
                    <div class="card">
                        <a href="">
                            <div class="header common-col">
                                <img src="<?=base_url('/images/headphones/airdopes1.jpeg')?>" class="img" alt="image" style="width: 50%;">
                            </div>
                             <div class="title">boAt Airdopes</div>
                            <h5>₹ 1,499</h5>
                        </a>
                    </div>
                </div>
            </div>
            <div class="row">

                <div class="col-sm-4 col-lg-4 col-md-4">
                    <div class="card">
                        <a href="">
                            <div class="header common-col">
                                <img src="<?=base_url('/images/headphones/airdopes2.jpeg')?>" class="img" alt="image" style="width: 50%;">
                            </div>
                            <div class="title">boAt Airdopes with ASAP charge Bluetooh</div>
                            <h5>₹ 1,999</h5>
                        </a>
                    </div>
                </div>
                <div class="col-sm-4 col-lg-4 col-md-4">
                    <div class="card">
                        <a href="">
                            <div class="header common-col">
                                <img src="<?=base_url('/images/headphones/boat-bassheads.jpeg')?>" class="img"
                                    alt="img" style="width: 50%;">
                            </div>
                            <div class="title">boAt Rockerz</div>
                            <h5>₹ 1,899</h5>
                        </a>
                    </div>
                </div>
                <div class="col-sm-4 col-lg-4 col-md-4">
                    <div class="card">
                        <a href="">
                            <div class="header common-col">
                                <img src="<?=base_url('/images/headphones/boat-rockerz.jpeg')?>" class="img"
                                    alt="image" style="width: 30%;">
                            </div>
                            <div class="title">boAt Rockerz 450 Bluetooth Headset</div>
                            <h5>₹ 1,199</h5>
                        </a>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-4 col-lg-4 col-md-4">
                    <div class="card">
                        <a href="">
                            <div class="header common-col">
                                <img src="<?=base_url('/images/headphones/fighter.jpeg')?>" class="img" alt="image" style="width: 30%;">
                            </div>
                            <div class="title">CatBull in-ear bluetooth headset</div>
                            <h5>₹ 999</h5>
                        </a>
                    </div>
                </div>
                <div class="col-sm-4 col-lg-4 col-md-4">
                    <div class="card">
                        <a href="">
                            <div class="header common-col">
                                <img src="<?=base_url('/images/headphones/boat-speaker.jpeg')?>" class="img"
                                    alt="img" style="width: 50%;">
                            </div>
                            <div class="title">boAt Stone 1500 40 W Bluetooth Speaker</div>
                            <h5> ₹ 1,500</h5>
                        </a>
                    </div>
                </div>
           
            </div>
        </div>
    </div>
</div>