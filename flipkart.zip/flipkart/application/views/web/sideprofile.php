<style>
.profile {
    margin-top: 10px;
}

.sub-menu {
    padding: 10px;
}

span {
    color: #2874f0;

}

.material-icons {
    font-size: 20px;
    color: #2874f0;
}

.profile-name {
    background-color: white;
    padding: 5px;
    width: 100%;
    margin-left: 0px;
}

.profile-edit {
    background-color: white;
    padding-left: 40px;
}

.profile-edit .nameupdate {
    padding: 20px;
    text-align: center;
}

.profile-edit .row {
    width: 60%;
    padding: 10px;
}

h3 {
    font-size: 18px;
    font-family: system-ui, sans-serif;
}
h4, p{
    font-size: 16px;
    font-family: system-ui, sans-serif;
}
.sub-details img{
    margin-left: -40px;
    width: 107%;
    margin-top: 20px;
}

</style>
<div class="profile" style="margin-top: 80px;">
    <!-- <?=$this->session->uid?> -->
    <div class="container">
        <div class="row">
            <div class="col-sm-3">
                <div class="row profile-name">
                    <strong>
                        <div class="col-sm-3">
                            <img src="<?=base_url('/images/profile/img.svg')?>" alt="">
                        </div>
                        <div class="col-sm-4">
                            Hello,
                            <?=$this->session->name?>
                        </div>
                    </strong>
                </div>

                <div class="row sub-menu">
                    <div class="list-group">
                        <a href="#" class="list-group-item">MY ORDERS</a>

                        <span class="list-group-item"><i class="material-icons">&#xe7fd;</i> ACCOUNT
                            SETTINGS</span>
                        <a href="<?=base_url('home/profile')?>" class="list-group-item">Profile Information</a>
                        <a href="<?=base_url('home/address')?>" class="list-group-item">Manage Addresses</a>
                        <a href="#" class="list-group-item">PAN Card Information</a>

                        <span href="#" class="list-group-item"> <i class="material-icons">&#xe850;</i>
                            PAYMENTS</span>
                        <a href="#" class="list-group-item">Gift Cards ₹0</a>
                        <a href="#" class="list-group-item">Saved UPI</a>
                        <a href="#" class="list-group-item">Saved Cards</a>

                        <span href="#" class="list-group-item"> <i class="material-icons">&#xe8af;</i> MY
                            CHATS</span>

                        <span href="#" class="list-group-item"><i class="material-icons">&#xe2c9;</i> MY
                            STUFF</span>
                        <a href="#" class="list-group-item">My Coupons</a>
                        <a href="#" class="list-group-item">My Reviews & Ratings</a>
                        <a href="#" class="list-group-item">All Notifications</a>
                        <a href="#" class="list-group-item">My Wishlist</a>

                        <a href="<?=base_url('home/logout')?>" class="list-group-item"><i
                                class="material-icons">&#xe8ac;</i> LOGOUT</a>

                    </div>
                </div>
            </div>