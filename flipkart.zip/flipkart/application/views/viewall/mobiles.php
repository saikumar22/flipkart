<style>
    .title{
    text-align: center;
    color: black;
    font-weight: bold;
}
</style>
<div class="mobiles view-list">
    <div class="container-fluid">
        <div class="fashion-header">
            <h3><b>Best selling Phones</b></h3>
        </div>
        <div class="mobile-view" style="padding: 20px;">
            <div class="row">
                <div class="col-sm-4 col-lg-4 col-md-4">
                    <div class="card">
                        <a href="<?=base_url('home/productview')?>">
                            <div class="header common-col">
                                <img src="<?=base_url('/images/mobiles/apple-iphone.webp')?>" class="img"
                                    alt="img">
                            </div>
                            <div class="title">Apple iphone</div >
                            <h5>Marine Green, 128GB</h5>
                            <p>Rs.98,999</p>
                        </a>
                    </div>
                </div>
                <div class="col-sm-4 col-lg-4 col-md-4">
                    <div class="card">
                        <a href="">
                            <div class="header common-col">
                                <img src="<?=base_url('/images/mobiles/oppo-reno3-pro.jpeg')?>" class="img" alt="img">
                            </div>
                            <div class="title">Oppo-reno3</div >
                            <h5>Midnight Ocean Black, 128GB</h5>
                            <p>Rs.15999</p>
                        </a>
                    </div>
                </div>
                <div class="col-sm-4 col-lg-4 col-md-4">
                    <div class="card">
                        <a href="">
                            <div class="header common-col">
                                <img src="<?=base_url('/images/mobiles/poco-m2-pro.jpeg')?>" class="img" alt="img">
                            </div>
                            <div class="title">POCO M2</div >
                            <h5> Black, 64GB (8GB RAM)</h5>
                            <p>Rs.15999</p>
                        </a>
                    </div>
                </div>

                <div class="col-sm-4 col-lg-4 col-md-4">
                    <div class="card">
                        <a href="">
                            <div class="header common-col">
                                <img src="<?=base_url('/images/mobiles/samsung-galaxy-m11.jpeg')?>" class="img"
                                    alt="img">
                            </div>
                            <div class="title">Samsung Galaxy M11</div >
                            <h5>Midnight Ocean Black, 128GB</h5>
                            <p>Rs.15999</p>
                        </a>
                    </div>
                </div>
                <div class="col-sm-4 col-lg-4 col-md-4">
                    <div class="card">
                        <a href="">
                            <div class="header common-col">
                                <img src="<?=base_url('/images/mobiles/p2.jpeg')?>" class="img" alt="img">
                            </div>
                            <div class="title">Samsung-galaxy s20</div >
                            <h5>Black, 128 GB (4GB RAM)</h5>
                            <p>Rs.15999</p>
                        </a>
                    </div>
                </div>
                <div class="col-sm-4 col-lg-4 col-md-4">
                    <div class="card">
                        <a href="">
                            <div class="header common-col">
                                <img src="<?=base_url('/images/mobiles/samsung-galaxy-a51.jpeg')?>" class="img"
                                    alt="img">
                            </div>
                            <div class="title">Samsung-galaxy-a51</div >
                            <h5>blue, 128GB (8GB RAM)</h5>
                            <p>Rs.15999</p>
                        </a>
                    </div>
                </div>

                <div class="col-sm-4 col-lg-4 col-md-4">
                    <div class="card">
                        <a href="">
                            <div class="header common-col">
                                <img src="<?=base_url('/images/mobiles/samsung-galaxy-m11.jpeg')?>" class="img"
                                    alt="img">
                            </div><br>
                            <div class="title">Samsung Galaxy M11</div >
                            <h5>Midnight Ocean Black, 128GB</h5>
                            <p>Rs.15999</p>
                        </a>
                    </div>
                </div>
                <div class="col-sm-4 col-lg-4 col-md-4">
                    <div class="card">
                        <a href="">
                            <div class="header common-col">
                                <img src="<?=base_url('/images/mobiles/tecno-camon-15.jpeg')?>" class="img" alt="img">
                            </div><br>
                            <div class="title">Tecno Camon</div >
                            <h5>Red, 128GB (8GB RAM)</h5>
                            <p>Rs.15999</p>
                        </a>
                    </div>
                </div>
                <div class="col-sm-4 col-lg-4 col-md-4">
                    <div class="card">
                        <a href="">
                            <div class="header common-col">
                                <img src="<?=base_url('/images/mobiles/oppo-reno3-pro.jpeg')?>" class="img" alt="img">
                            </div>
                            <div class="title">Oppo-reno3</div >
                            <h5>Midnight Ocean Black, 128GB</h5>
                            <p>Rs.15999</p>
                        </a>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>