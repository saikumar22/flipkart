<?php
class adminModel extends CI_Model {
public function __construct(){
$this->load->database('default');
$this->load->library('session');
}
public function delete($pid){
    return $this->db->delete("products", ['pid'=>$pid]);
}
public function updateJob($data,$pid) {
    return $this->db->update('products',$data, ['pid'=>$pid]);
}
}