<style>
.view-dress {
    background-color: white;
    margin-left: 10px;
    width: 82%;
    /* border: 1px solid red; */
}

.view-dress .image1 {
    width: 40%;
    margin-left: 70px;
    margin-top: 2px;

}

.view-dress .details {
    color: black;
    text-align: center;
}

.productlist a {
    color: black;
    text-decoration: none;
    text-transform: none;
}

.productlist a:hover {
    color: blue;
}

.productlist .col-sm-3 {
    padding: 20px;
}

.productlist .details .card {
    background-color: white;
}

.productlist .card:hover {
    box-shadow: rgba(50, 50, 93, 0.25) 0px 6px 12px -2px, rgba(0, 0, 0, 0.3) 0px 3px 7px -3px;
    /* margin-top: -20px; */
}

.common-col1 {
    padding: 10px;
}

.material-tooltip-main {
    float: right;
}

/* .productlist .details {
    margin-top: 10px;
} */
</style>
<div class="col-sm-8  view-dress">
    <ol class="breadcrumb col-sm-12" style="float: right;">
        <li><a href="<?=base_url('home/index')?>">Home</a></li>
        <li class="active"><a href="<?=base_url('home/products_views')?>">Dress</a></li>
    </ol>
    <div class="productlist">
        <div class="row">
            <div class="col-sm-3 col-xs-12">
                <div class="card">
                    <a href="">
                        <div class="header common-col1">
                            <button type="button" class="btn btn-danger btn-sm px-3 mb-2 material-tooltip-main"
                                data-toggle="tooltip" data-placement="top" title="Add to wishlist">
                                <span class="glyphicon">&#xe005;</span>
                            </button>
                            <img src="<?=base_url('/images/shirt/skyblue-dennis-lingo.jpeg')?>" class="image1"
                                alt="img">
                        </div>
                        <div class="details">
                            <div class="card">
                                <strong>Metronaut</strong>
                                <h5>Rs 799</h5>
                                <p>shirt</p>
                            </div>

                        </div>
                    </a>
                </div>
            </div>

            <div class="col-sm-3">
                <div class="card">
                    <a href="">
                        <div class="header common-col1">
                            <button type="button" class="btn btn-danger btn-sm px-3 mb-2 material-tooltip-main"
                                data-toggle="tooltip" data-placement="top" title="Add to wishlist">
                                <span class="glyphicon">&#xe005;</span>
                            </button>
                            <img src="<?=base_url('/images/tops/sleeve-top.jpeg')?>" class="image1" alt="img">
                        </div><br>
                        <div class="details">
                            <div class="card">
                                <strong>Sleeve-top</strong>
                                <h5>Rs 799</h5>
                                <p>Women Dark Blue Top</p>
                            </div>

                        </div>
                    </a>
                </div>
            </div>

            <div class="col-sm-3">
                <div class="card">
                    <a href="">
                        <div class="header common-col1">
                            <button type="button" class="btn btn-danger btn-sm px-3 mb-2 material-tooltip-main"
                                data-toggle="tooltip" data-placement="top" title="Add to wishlist">
                                <span class="glyphicon">&#xe005;</span>
                            </button>
                            <img src="<?=base_url('/images/t-shirt/tripr-original.jpeg')?>" class="image1" alt="img"
                                style="width: 45%;">
                        </div>
                        <div class="details">
                            <strong>Metronaut</strong>
                            <h5>Rs 999</h5>
                            <p>shirt</p>
                        </div>
                    </a>
                </div>
            </div>

            <div class="col-sm-3">
                <div class="card">
                    <a href="">
                        <div class="header common-col1">
                            <button type="button" class="btn btn-danger btn-sm px-3 mb-2 material-tooltip-main"
                                data-toggle="tooltip" data-placement="top" title="Add to wishlist">
                                <span class="glyphicon">&#xe005;</span>
                            </button>
                            <img src="<?=base_url('/images/tops/love-original.jpeg')?>" class="image1" alt="img"
                                style="width: 47%;">
                        </div><br>
                        <div class="details">
                            <strong>Sleeve Embroidered</strong>
                            <h5>Rs 1999</h5>
                            <p>Women Maroon Top</p>
                        </div>
                    </a>
                </div>
            </div>
        </div>

        <div class="row">

            <div class="col-sm-3">
                <div class="card">
                    <a href="">
                        <div class="header common-col1">
                            <button type="button" class="btn btn-danger btn-sm px-3 mb-2 material-tooltip-main"
                                data-toggle="tooltip" data-placement="top" title="Add to wishlist">
                                <span class="glyphicon">&#xe005;</span>
                            </button>
                            <img src="<?=base_url('/images/women-t-shirt/denzolee.jpeg')?>" class="image1" alt="img">
                        </div><br>
                        <div class="details">
                            <strong>Jhankhi</strong>
                            <h5>Min 30% Off</h5>
                            <p>Women Women T-shirt</p>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="card">
                    <a href="">
                        <div class="header common-col1">
                            <button type="button" class="btn btn-danger btn-sm px-3 mb-2 material-tooltip-main"
                                data-toggle="tooltip" data-placement="top" title="Add to wishlist">
                                <span class="glyphicon">&#xe005;</span>
                            </button>
                            <img src="<?=base_url('/images/t-shirt/blive.jpeg')?>" class="image1" alt="img"
                                style="width: 45%;">
                        </div><br>
                        <div class="details">
                            <strong>Blive</strong>
                            <h5>Up to 20%</h5>
                            <p>T-shirt</p>
                        </div>
                    </a>
                </div>
            </div>

        </div>
    </div>
</div>
</div>