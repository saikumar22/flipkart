<!----------------------------------------------------------------Best Price On Fashion -->

<div class="product">
    <div class="container-fluid" style="margin-top: 80px;">
        <div class="fashion-header">
            <div class="row">
                <div class="col-sm-11">
                    <h3><b>Best Price On Fashion</b></h3>
                </div>
                <div class=" col-sm-1 view-all">
                    <a href="<?=base_url();?>home/best_deals" class="btn btn-primary">VIEW ALL</a>
                </div>
            </div>
        </div>
        <div class="carousel carousel-nav"
            data-flickity='{ "asNavFor": ".carousel-main", "contain": true, "pageDots": false }'>

            <div class="carousel-cell">
                <div class="card col-xs-12">
                    <a href="">
                        <div class="header common-col">
                            <img src="<?=base_url('/images/fashion/shirt.jpeg')?>" class="img" alt="img"
                                style="width: 50%;">
                        </div>
                        <strong>Denim shirt</strong>
                        <h5>Min 60% off</h5>
                        <p>T-Shirts</p>
                    </a>
                </div>
            </div>

            <div class="carousel-cell">
                <div class="card col-xs-12">
                    <a href="">
                        <div class="header common-col">
                            <img src="<?=base_url('/images/fashion/wallet.jpeg')?>" class="img" alt="img"
                                style="width: 65%;">
                        </div>
                        <strong>Men Wallet</strong>
                        <h5>Min 30% off</h5>
                        <p>wallets</p>
                    </a>
                </div>

            </div>

            <div class="carousel-cell">
                <div class="card col-xs-12">
                    <a href="">
                        <div class="header common-col">
                            <img src="<?=base_url('/images/fashion/saree.jpeg')?>" class="img" alt="img"
                                style="width: 40%;">
                        </div>
                        <strong>Saree</strong>
                        <h5>Min 50% off</h5>
                        <p>Saree</p>
                    </a>
                </div>
            </div>

            <div class="carousel-cell">
                <div class="card col-xs-12">
                    <a href="">
                        <div class="header common-col">
                            <img src="<?=base_url('/images/fashion/woodland-footware.jpeg')?>" class="img" alt="img"
                                style="width: 60%;">
                        </div>
                        <strong>Woodland</strong>
                        <h5>Min 60% off</h5>
                        <p>Footware</p>
                    </a>
                </div>
            </div>

            <div class="carousel-cell">
                <div class="card col-xs-12">
                    <a href="">
                        <div class="header common-col">
                            <img src="<?=base_url('/images/fashion/shirt1.jpeg')?>" class="img" alt="img"
                                style="width: 45%;">
                        </div>
                        <strong>Denim shirt</strong>
                        <h5>Min 60% off</h5>
                        <p>T-Shirts</p>
                    </a>
                </div>
            </div>


            <div class="carousel-cell" style="width: 200px;">
                <div class="card col-xs-12">
                    <a href="">
                        <div class="header common-col">
                            <img src="<?=base_url('/images/fashion/shoes.jpeg')?>" class="img" alt="img"
                                style="width: 68%;">
                        </div>
                        <strong>Sparx-footware</strong>
                        <h5>Min 20% off</h5>
                        <p>Shoes</p>
                    </a>
                </div>
            </div>

            <div class="carousel-cell" style="width: 200px;">
                <div class="card col-xs-12">
                    <a href="">
                        <div class="header common-col">
                            <img src="<?=base_url('/images/fashion/wallet-ladys.jpeg')?>" class="img" alt="img"
                                style="width: 70%;">
                        </div>
                        <strong>Wallet Ladys</strong>
                        <h5>Min 60% off</h5>
                        <p>Wallet</p>
                    </a>
                </div>
            </div>

            <div class="carousel-cell">
                <div class="card col-xs-12">
                    <a href="">
                        <div class="header common-col">
                            <img src="<?=base_url('/images/fashion/footware.jpeg')?>" class="img" alt="img"
                                style="width: 60%;">
                        </div>
                        <strong>Footware</strong>
                        <h5>Min 60% off</h5>
                        <p>mens footware</p>
                    </a>
                </div>
            </div>
            </a>
        </div>
    </div>
</div>





<!-----------------------------------------------------------------------Mobiles -->
<div class="product">
    <div class="container-fluid">
        <div class="fashion-header">
            <div class="row">
                <div class="col-sm-11">
                    <h3><b>Best selling Phones</b></h3>
                </div>
                <div class=" col-sm-1 view-all">
                    <a href="<?=base_url();?>home/mobiles" class="btn btn-primary">VIEW ALL</a>
                </div>
            </div>
        </div>

        <div class="carousel carousel-nav"
            data-flickity='{ "asNavFor": ".carousel-main", "contain": true, "pageDots": false }' id="mobiles">
            <div class="carousel-cell">
                <div class="card">
                    <a href="">
                        <div class="header common-col">
                            <img src="<?=base_url('/images/mobiles/samsung-galaxy-a31.jpeg')?>" class="img" alt="img">
                        </div>
                        <strong>Samsung-galaxy-A31</strong>
                        <h5>Marine Green, 128GB</h5>
                        <p>Rs.15999</p>
                    </a>
                </div>
            </div>
            <div class="carousel-cell">
                <div class="card">
                    <a href="">
                        <div class="header common-col">
                            <img src="<?=base_url('/images/mobiles/oppo-reno3-pro.jpeg')?>" class="img" alt="img">
                        </div>
                        <strong>Oppo-reno3</strong>
                        <h5>Midnight Ocean Black, 128GB</h5>
                        <p>Rs.15999</p>
                    </a>
                </div>
            </div>
            <div class="carousel-cell">
                <div class="card">
                    <a href="">
                        <div class="header common-col">
                            <img src="<?=base_url('/images/mobiles/poco-m2-pro.jpeg')?>" class="img" alt="img">
                        </div>
                        <strong>POCO M2</strong>
                        <h5> Black, 64GB (8GB RAM)</h5>
                        <p>Rs.15999</p>
                    </a>
                </div>
            </div>
            <div class="carousel-cell">
                <div class="card">
                    <a href="">
                        <div class="header common-col">
                            <img src="<?=base_url('/images/mobiles/samsung-galaxy-a51.jpeg')?>" class="img" alt="img">
                        </div>
                        <strong>Samsung-galaxy-a51</strong>
                        <h5>blue, 128GB (8GB RAM)</h5>
                        <p>Rs.15999</p>
                    </a>
                </div>
            </div>
            <div class="carousel-cell">
                <div class="card">
                    <a href="">
                        <div class="header common-col">
                            <img src="<?=base_url('/images/mobiles/samsung-galaxy-m11.jpeg')?>" class="img" alt="img">
                        </div>
                        <strong>Samsung Galaxy M11</strong>
                        <h5>Midnight Ocean Black, 128GB</h5>
                        <p>Rs.15999</p>
                    </a>
                </div>
            </div>
            <div class="carousel-cell" style="width: 200px;">
                <div class="card">
                    <a href="">
                        <div class="header common-col">
                            <img src="<?=base_url('/images/mobiles/p2.jpeg')?>" class="img" alt="img">
                        </div>
                        <strong>Samsung-galaxy s20</strong>
                        <h5>Black, 128 GB (4GB RAM)</h5>
                        <p>Rs.15999</p>
                    </a>
                </div>
            </div>

            <div class="carousel-cell" style="width: 200px;">
                <div class="card">
                    <a href="">
                        <div class="header common-col">
                            <img src="<?=base_url('/images/mobiles/tecno-camon-15.jpeg')?>" class="img" alt="img">
                        </div>
                        <strong>Tecno Camon</strong>
                        <h5>Red, 128GB (8GB RAM)</h5>
                        <p>Rs.15999</p>
                    </a>
                </div>
            </div>

            <div class="carousel-cell">
                <div class="card">
                    <a href="">
                        <div class="header common-col">
                            <img src="<?=base_url('/images/mobiles/samsung-galaxy-m11.jpeg')?>" class="img" alt="img">
                        </div>
                        <strong>Samsung Galaxy M11</strong>
                        <h5>Midnight Ocean Black, 128GB</h5>
                        <p>Rs.15999</p>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>


<!-----------------------------------------------------------------------Men's Clothing -->
<div class="product">
    <div class="container-fluid">
        <div class="fashion-header">
            <div class="row">
                <div class="col-sm-11">
                    <h3><b>Men's Clothing</b></h3>
                </div>
                <div class=" col-sm-1 view-all">
                    <a href="<?=base_url();?>home/mens" class="btn btn-primary">VIEW ALL</a>
                </div>
            </div>
        </div>

        <div class="carousel carousel-nav"
            data-flickity='{ "asNavFor": ".carousel-main", "contain": true, "pageDots": false }'>
            <div class="carousel-cell">
                <div class="card">
                    <a href="">
                        <div class="header common-col">
                            <img src="<?=base_url('/images/shirt/skyblue-dennis-lingo.jpeg')?>" class="img" alt="img"
                                style="width: 29%;">
                        </div>
                        <strong>Metronaut</strong>
                        <h5>Up to 10%</h5>
                        <p>shirt</p>
                    </a>
                </div>
            </div>
            <div class="carousel-cell">
                <div class="card">
                    <a href="">
                        <div class="header common-col">
                            <img src="<?=base_url('/images/t-shirt/blive.jpeg')?>" class="img" alt="img"
                                style="width: 33%;">
                        </div>
                        <strong>Blive</strong>
                        <h5>Up to 20%</h5>
                        <p>T-shirt</p>
                    </a>
                </div>
            </div>
            <div class="carousel-cell">
                <div class="card">
                    <a href="">
                        <div class="header common-col">
                            <img src="<?=base_url('/images/pants/mens-tr.jpeg')?>" class="img" alt="img"
                                style="width: 23%;">
                        </div>
                        <strong>formal-classio</strong>
                        <h5>Under ₹1500</h5>
                        <p>Pants</p>
                    </a>
                </div>
            </div>
            <div class="carousel-cell">
                <div class="card">
                    <a href="">
                        <div class="header common-col">
                            <img src="<?=base_url('/images/shirt/raymond.jpeg')?>" class="img" alt="img"
                                style="width: 38%;">
                        </div>
                        <strong>Raymond</strong>
                        <h5>Up to 20%</h5>
                        <p>Blazer</p>
                    </a>
                </div>
            </div>
            <div class="carousel-cell">
                <div class="card">
                    <a href="">
                        <div class="header common-col">
                            <img src="<?=base_url('/images/shirt/kurta-pajama.jpeg')?>" class="img" alt="img"
                                style="width: 20%;">
                        </div>
                        <strong>SKAVIJ</strong>
                        <h5>Min 50% Off</h5>
                        <p>Men Kurta and Churidar</p>
                    </a>
                </div>
            </div>
            <div class="carousel-cell" style="width: 200px;">
                <div class="card">
                    <a href="">
                        <div class="header common-col">
                            <img src="<?=base_url('/images/shirt/hangup.jpeg')?>" class="img" alt="img"
                                style="width: 30%;">
                        </div>
                        <strong>Floral Print Men Waistcoat</strong>
                        <h5>Min 20% Off</h5>
                        <p>Hangup</p>
                    </a>
                </div>
            </div>

            <div class="carousel-cell" style="width: 200px;">
                <a href="">
                    <div class="card">
                        <div class="header common-col">
                            <img src="<?=base_url('/images/shirt/track.jpeg')?>" class="img" alt="img"
                                style="width: 45%;">
                        </div>
                        <strong>TRIPR </strong>
                        <h5>Min 10% Off</h5>
                        <p>Black Track Pants</p>
                    </div>
                </a>
            </div>

            <div class="carousel-cell">
                <div class="card">
                    <a href="">
                        <div class="header common-col">
                            <img src="<?=base_url('/images/shirt/blue-base.jpeg')?>" class="img" alt="img"
                                style="width: 30%;">
                        </div>
                        <strong>Spread Collar Casual Shirt</strong>
                        <h5>Min 30% Off</h5>
                        <p>Casual Shirt</p>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

