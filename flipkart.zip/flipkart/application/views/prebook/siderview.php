<style>
.bigsale img {
    width: 100%;
}

.bigsale {
    background-color: #f6f6f6;
}

.bigsale h4 {
    padding: 7px;
}
</style>
<div class="container-fluid bigsale">
    <div class="row">
        <h4> <b> TVs & Appliances Big Savings Days </b></h4>
        <div class="top bigsale">
            <div class="col-sm-12">
                <a href=""><img src="<?=base_url('images/slider/p1.png')?>" alt=""></a>
            </div>
            <div class="col-sm-12">
                <a href=""><img src="<?=base_url('images/slider/p2.png')?>" alt=""></a>
            </div>
            <div class="col-sm-12">
                <a href=""><img src="<?=base_url('images/slider/p3.png')?>" alt=""></a>
            </div>

            <div class=" latest">
                <div class="col-sm-12">
                    <a href=""><img src="<?=base_url('images/slider/p4.png')?>" alt=""></a>
                </div>
                <div class="col-sm-12">
                    <div class="col-sm-4">
                        <a href=""><img src="<?=base_url('images/slider/ele1.jpg')?>" alt=""></a>
                    </div>
                    <div class="col-sm-4">
                        <a href=""><img src="<?=base_url('images/slider/ele2.jpg')?>" alt=""></a>
                    </div>
                    <div class="col-sm-4">
                        <a href=""><img src="<?=base_url('images/slider/ele3.jpg')?>" alt=""></a>
                    </div>
                    <div class="col-sm-4">
                        <a href=""><img src="<?=base_url('images/slider/ele4.jpg')?>" alt=""></a>
                    </div>
                    <div class="col-sm-4">
                        <a href=""><img src="<?=base_url('images/slider/ele5.jpg')?>" alt=""></a>
                    </div>
                    <div class="col-sm-4">
                        <a href=""><img src="<?=base_url('images/slider/ele6.jpg')?>" alt=""></a>
                    </div>
                </div>
            </div>
            <div class=" latest">
                <div class="col-sm-12">
                    <a href=""><img src="<?=base_url('images/slider/h.png')?>" alt=""></a>
                </div>
                <div class="col-sm-12">
                    <a href=""><img src="<?=base_url('images/slider/h1.png')?>" alt=""></a>
                </div>
                <div class="col-sm-12">
                    <a href=""><img src="<?=base_url('images/slider/h2.png')?>" alt=""></a>
                </div>
                <div class="col-sm-12">
                    <a href=""><img src="<?=base_url('images/slider/h3.png')?>" alt=""></a>
                </div>
                <div class="col-sm-12">
                    </a>
                    <a href=""><img src="<?=base_url('images/slider/h4.png')?>" alt=""></a>
                </div>
            </div>
            <div class=" latest">
                <div class="col-sm-12">
                    <a href=""><img src="<?=base_url('images/slider/k.png')?>" alt=""></a>
                </div>
                <div class="col-sm-12">
                    <a href=""><img src="<?=base_url('images/slider/k1.png')?>" alt=""></a>
                </div>
                <div class="col-sm-12">
                    <a href=""><img src="<?=base_url('images/slider/k2.png')?>" alt=""></a>
                </div>
                <div class="col-sm-12">
                    <a href=""><img src="<?=base_url('images/slider/k3.png')?>" alt=""></a>
                </div>
            </div>
            <div class=" latest">
                <div class="col-sm-12">
                    <a href=""><img src="<?=base_url('images/slider/b.png')?>" alt=""></a>
                </div>
                <div class="col-sm-12">
                    <a href=""><img src="<?=base_url('images/slider/b1.png')?>" alt=""></a>
                </div>
                <div class="col-sm-12">
                    <a href=""><img src="<?=base_url('images/slider/b2.png')?>" alt=""></a>
                </div>
                <div class="col-sm-12">
                    <a href=""><img src="<?=base_url('images/slider/b3.png')?>" alt=""></a>
                </div>
            </div>
            <div class="col-sm-12">
                <a href=""><img src="<?=base_url('images/slider/final.png')?>" alt=""></a>
            </div>
        </div>
    </div>
</div>