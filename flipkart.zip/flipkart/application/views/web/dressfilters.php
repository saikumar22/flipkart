<style>
.product_view {
    background-color: #f6f6f6;
}

.filter {
    background-color: white;
    /* padding: 30px; */
}
.subcat a{
    color: black;
    text-transform: none;
    text-decoration: none;
}
.subcat a:hover{
    color:blue;
}

</style>
<div class="container-fluid product_view">
    <div class="row">
        <div class="col-sm-2 filter">
            <!-- Section: Sidebar -->
            <section>

                <!-- Section: Filters -->
                <section>

                    <h3>Filters</h3><hr>

                    <!-- Section: Categories -->
                    <section>

                        <h5 class="small text-uppercase"><b>Subcategories </b></h5>
                        <div class="text-muted mb-5 subcat">
                            <p class="mb-4">Return to <a href="#!" class="card-link-secondary"><strong>Clothing, Shoes,
                                        Accessories</strong></a></p>

                            <p class="mb-3"><a href="#!" class="card-link-secondary">Dresses</a></p>
                            <p class="mb-3"><a href="#!" class="card-link-secondary">Tops, Tees & Blouses</a></p>
                            <p class="mb-3"><a href="#!" class="card-link-secondary">Sweaters</a></p>
                            <p class="mb-3"><a href="#!" class="card-link-secondary">Fashion Hoodies & Sweatshirts</a>
                            </p>
                            <p class="mb-3"><a href="#!" class="card-link-secondary">Jeans</a></p>
                            <p class="mb-3"><a href="#!" class="card-link-secondary">Pants</a></p>
                            <p class="mb-3"><a href="#!" class="card-link-secondary">Skirts</a></p>
                            <p class="mb-3"><a href="#!" class="card-link-secondary">Shorts</a></p>
                            <p class="mb-3"><a href="#!" class="card-link-secondary">Leggings</a></p>
                            <p class="mb-3"><a href="#!" class="card-link-secondary">Swimsuits & Cover Ups</a></p>
                            <p class="mb-3"><a href="#!" class="card-link-secondary">Lingerie, Sleep & Lounge</a></p>
                            <p class="mb-3"><a href="#!" class="card-link-secondary">Jumpsuits, Rompers & Overalls</a>
                            </p>
                            <p class="mb-3"><a href="#!" class="card-link-secondary">Coats, Jackets & Vests</a></p>
                            <p class="mb-3"><a href="#!" class="card-link-secondary">Suiting & Blazers</a></p>
                            <p class="mb-0"><a href="#!" class="card-link-secondary">Socks & Hosiery</a></p>
                        </div>

                    </section>
                    <hr>

                    <!-- Section: Price -->
                    <section class="mb-4">

                        <h6 class="font-weight-bold mb-3 small text-uppercase">Price</h6>

                        <div class="form-check pl-0 mb-3">
                            <input type="radio" class="form-check-input" id="under25" name="materialExampleRadios">
                            <label class="form-check-label small text-lowercase card-link-secondary" for="under25">Under
                                5000</label>
                        </div>
                        <div class="form-check pl-0 mb-3">
                            <input type="radio" class="form-check-input" id="2550" name="materialExampleRadios">
                            <label class="form-check-label small text-lowercase card-link-secondary" for="2550">5000 to
                                10000</label>
                        </div>
                        <div class="form-check pl-0 mb-3">
                            <input type="radio" class="form-check-input" id="50100" name="materialExampleRadios">
                            <label class="form-check-label small text-lowercase card-link-secondary" for="50100">10000
                                to
                                15000</label>
                        </div>
                        <div class="form-check pl-0 mb-3">
                            <input type="radio" class="form-check-input" id="100200" name="materialExampleRadios">
                            <label class="form-check-label small text-lowercase card-link-secondary" for="100200">15000
                                to
                                20000</label>
                        </div>
                        <div class="form-check pl-0 mb-3">
                            <input type="radio" class="form-check-input" id="200above" name="materialExampleRadios">
                            <label class="form-check-label small text-lowercase card-link-secondary"
                                for="200above">20000 &
                                Above</label>
                        </div>

                    </section>
                    <hr>
                    <!-- Section: Price -->

                    <!-- Section: Price version 2 -->
                    <section class="mb-4">

                        <h6 class="font-weight-bold mb-3 small text-uppercase">Price</h6>

                        <div class="slider-price d-flex align-items-center my-4">
                            <span class="font-weight-normal small text-muted mr-2">RS 0</span>
                            <form class="multi-range-field w-100 mb-1">
                                <input id="multi" class="multi-range" type="range" />
                            </form>
                            <span class="font-weight-normal small text-muted ml-2">RS 100000</span>
                        </div>

                    </section>
                    <hr>
                    <!-- Section: Price version 2 -->

                    <!-- Section: Size -->
                    <section class="mb-4">

                        <h6 class="font-weight-bold mb-3 small text-uppercase">Discount</h6>

                        <div class="form-check pl-0 mb-3">
                            <input type="checkbox" class="form-check-input filled-in" id="10%">
                            <label class="form-check-label small text-uppercase card-link-secondary"
                                for="10%">10%</label>
                        </div>
                        <div class="form-check pl-0 mb-3">
                            <input type="checkbox" class="form-check-input filled-in" id="20%">
                            <label class="form-check-label small text-uppercase card-link-secondary"
                                for="20%">20%</label>
                        </div>
                        <div class="form-check pl-0 mb-3">
                            <input type="checkbox" class="form-check-input filled-in" id="30%">
                            <label class="form-check-label small text-uppercase card-link-secondary"
                                for="30%">30%</label>
                        </div>
                        <div class="form-check pl-0 mb-3">
                            <input type="checkbox" class="form-check-input filled-in" id="40%">
                            <label class="form-check-label small text-uppercase card-link-secondary"
                                for="40%">40%</label>
                        </div>
                        <a class="btn btn-link text-muted p-0" data-toggle="collapse" href="#collapseExample"
                            aria-expanded="false" aria-controls="collapseExample">
                            More
                        </a>
                        <div class="collapse pt-3" id="collapseExample">
                            <div class="form-check pl-0 mb-3">
                                <input type="checkbox" class="form-check-input filled-in" id="50%">
                                <label class="form-check-label small text-uppercase card-link-secondary"
                                    for="50%">50%</label>
                            </div>
                            <div class="form-check pl-0 mb-3">
                                <input type="checkbox" class="form-check-input filled-in" id="55%">
                                <label class="form-check-label small text-uppercase card-link-secondary"
                                    for="55%">55%</label>
                            </div>
                            <div class="form-check pl-0 mb-3">
                                <input type="checkbox" class="form-check-input filled-in" id="60%">
                                <label class="form-check-label small text-uppercase card-link-secondary"
                                    for="60%">60%</label>
                            </div>
                            <div class="form-check pl-0 mb-3">
                                <input type="checkbox" class="form-check-input filled-in" id="70%">
                                <label class="form-check-label small text-uppercase card-link-secondary"
                                    for="70%">70%</label>
                            </div>
                        </div>

                    </section>
                    <hr>
                </section>
                <!-- Section: Filters -->

            </section>
            <!-- Section: Sidebar -->
        </div>

        <script>
        $('#multi').mdbRange({
            single: {
                active: true,
                multi: {
                    active: true,
                    rangeLength: 1
                },
            }
        });
        </script>