-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 03, 2021 at 01:57 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `flipkart`
--

-- --------------------------------------------------------

--
-- Table structure for table `address`
--

CREATE TABLE `address` (
  `address_id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `address` varchar(500) NOT NULL,
  `name` varchar(20) NOT NULL,
  `mobile` varchar(12) NOT NULL,
  `pincode` varchar(10) NOT NULL,
  `locality` varchar(100) NOT NULL,
  `city` varchar(200) NOT NULL,
  `state` varchar(25) NOT NULL,
  `landmark` varchar(300) NOT NULL,
  `alternate` varchar(20) NOT NULL,
  `type` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `address`
--

INSERT INTO `address` (`address_id`, `uid`, `address`, `name`, `mobile`, `pincode`, `locality`, `city`, `state`, `landmark`, `alternate`, `type`) VALUES
(1, 2, '4-11 warangal', 'saikumar', '7894561230', '500039', 'warangal', 'warangal', 'telangana', '4-11 warangal', '9874561230', 'Home'),
(3, 1, 'hyderabad', 'admin', '789456123', '500069', '', '', '', '', '', 'Home'),
(4, 3, 'gachibowli, hyderabad', 'sathish', '9859674213', '500067', 'hyderbad', 'hyderabad', 'telangana', '', '859622326', 'Work');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `quantity` int(20) NOT NULL DEFAULT 1,
  `price` varchar(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `total` int(20) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`cid`, `uid`, `pid`, `quantity`, `price`, `name`, `total`, `date`) VALUES
(12, 5, 11, 2, '14999', 'realme C25s (Watery Blue, 128 GB)  (4 GB RAM)\r\n', 29998, '2021-08-01'),
(14, 4, 7, 2, '29999', 'OPPO Reno6 5G (Stellar Black, 128 GB)  (8 GB RAM)#JustHere\r\n', 59998, '2021-08-01'),
(15, 3, 14, 1, '17999', 'MOTOROLA G9 Power (Electric Violet, 64 GB)  (4 GB RAM)\r\n', 17999, '2021-08-01'),
(16, 3, 15, 2, '82999', 'APPLE iPhone 12 (Blue, 128 GB)\r\n', 165998, '2021-08-01'),
(17, 2, 4, 1, '117999', 'SAMSUNG Galaxy S10 Plus (Ceramic White, 1 TB)  (12 GB RAM)\r\n', 117999, '2021-08-02'),
(19, 2, 13, 2, '13999', 'POCO M3 Pro 5G (Power Black, 64 GB)  (4 GB RAM)#JustHere\r\n', 27998, '2021-08-02'),
(21, 6, 14, 1, '17999', 'MOTOROLA G9 Power (Electric Violet, 64 GB)  (4 GB RAM)\r\n', 17999, '2021-08-03');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `pid` int(11) NOT NULL,
  `image` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `price` varchar(20) NOT NULL,
  `aprice` varchar(20) NOT NULL,
  `storage` varchar(10) NOT NULL,
  `highlights` varchar(500) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `des_1` varchar(1000) NOT NULL,
  `des_img1` varchar(200) NOT NULL,
  `des_2` varchar(1000) NOT NULL,
  `des_img2` varchar(200) NOT NULL,
  `general` varchar(400) NOT NULL,
  `ram` varchar(100) NOT NULL,
  `modelnumber` varchar(100) NOT NULL,
  `modelname` varchar(100) NOT NULL,
  `color` varchar(200) NOT NULL,
  `browsetype` varchar(100) NOT NULL,
  `categoryname` varchar(100) NOT NULL,
  `date_created` varchar(20) NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`pid`, `image`, `name`, `price`, `aprice`, `storage`, `highlights`, `description`, `des_1`, `des_img1`, `des_2`, `des_img2`, `general`, `ram`, `modelnumber`, `modelname`, `color`, `browsetype`, `categoryname`, `date_created`) VALUES
(4, 'samsung-galaxy-s10.jpeg', 'SAMSUNG Galaxy S10 Plus (Ceramic White, 1 TB)  (12 GB RAM)\r\n', '117999', '120999', '128GB', '12 GB RAM | 1 TB ROM | Expandable Upto 512 GB\r\n16.26 cm (6.4 inch) Quad HD+ Display\r\n16MP + 12MP | 10MP + 8MP Dual Front Camera\r\n4100 mAh Lithium-ion Battery\r\nExynos 9 9820 Processor', 'Get ready to explore the next generation of powerful computing and mobile photography with the Samsung Galaxy S10 Plus. It comes with an Intelligent Camera that automatically optimizes its settings to give you picture-perfect photos. That\'s not all, the Samsung S10 Plus has the Infinity-O Display and a seamless design that make this smartphone a true masterpiece.\r\n', 'No Notch, No Distractions - Design\r\nThe Samsung S10 Plus is designed to give you a smartphone experience like never before. How? It has no notch and no distractions, which make it a smartphone worth showing off. Its Precise Laser Cutting, On-screen Security, and its Dynamic AMOLED screen ensure that this smartphone is easy on your eyes while also enhancing your user experience.', '', '30 W Dart Charge\r\nLow battery is a buzz killer during gaming marathons. Hence, this smartphone comes with a 30 W Dart Charge that ensures that the battery is charged 100% with about 65 minutes of charging.\r\nInfinity-O Display\r\nTo ensure an interruption-free experience, the Samsung S10 Plus comes with the Infinity-O Display.', '', 'Handset (Non-removable Battery Included), Earphones, Travel Adapter, USB Cable, Ejection Pin, User Manual\r\n', '6GB', 'SM-G975FCWHINS\r\n', 'Galaxy S10 Plus\r\n', 'Ceramic White\r\n', 'Smartphones', 'Mobile', '2021-07-29 20:05:27'),
(7, 'reno6-5g.jpeg', 'OPPO Reno6 5G (Stellar Black, 128 GB)  (8 GB RAM)#JustHere\r\n', '29999', '40000', '128GB', '4 GB RAM | 64 GB ROM | Expandable Upto 256 GB\r\n16.51 cm (6.5 inch) Full HD+ Display\r\n48MP + 2MP + 2MP | 16MP Front Camera\r\n5000 mAh Battery\r\nMediaTek Helio G95 Processor\r\n30W Charger', 'The realme Narzo 30, make your mobile gaming experience smooth, lag-free, and immersive. This smartphone runs on the Helio G95 Gaming Processor for intense gaming, a 90 Hz Ultra-smooth Display for smooth scrolling, and a 5000 mAh Massive Battery for hours of gaming marathons.\r\n\r\nThe OPPO Reno6 5G features up to 8 GB + 128 GB of internal storage for all your memories. And, in case that’s not enough, you can enjoy its RAM expansion capabilities as well. This mobile phone features a fingerprint-proof finish for an aesthetic appeal. And, with the Flash Snapshot, powered by OPPO exclusive Image Clear Engine and Color Temperature Sensor, the mobile phone can automatically focus as soon as you kickstart the camera.', '\r\nFingerprint-proof Finish\r\nThe OPPO Reno6 5G has a unique and fingerprint-proof finish so that the mobile phone looks aesthetically appealing.', '', 'Slim and Light\r\nThis mobile phone features an Ultra-Slim Retro Design so that you can enjoy its sleek, flat-edged middle frame construction for comfortable usage.', '', '\r\nHandset, Charger, USB Cable, Earphone, SIM Ejector Tool, Protective Case, Quick Start Guide, Safety Guide', '6GB', 'CPH2251', 'Reno6 5G\r\n', 'Stellar Black\r\n', 'Smartphones', 'Mobile', '2021-07-29 20:07:43'),
(11, 'c25s.jpeg', 'realme C25s (Watery Blue, 128 GB)  (4 GB RAM)\r\n', '14999', '17999', '128GB', '4 GB RAM | 128 GB ROM | Expandable Upto 256 GB\r\n16.51 cm (6.5 inch) HD+ Display\r\n13MP + 2MP + 2MP | 8MP Front Camera\r\n6000 mAh Battery\r\nMediaTek Helio G85 Processor', '\r\nThe realme C25s comes with a 13 MP AI Triple Camera that helps you capture stellar photos of all that’s around you. Its 16.5 cm (6.5) large display will give you a clear and expansive view of games, movies, and more. And, its instant fingerprint sensor can be used to securely and instantly unlock your device.\r\n', 'No Notch, No Distractions - Design\r\nThe Samsung S10 Plus is designed to give you a smartphone experience like never before. How? It has no notch and no distractions, which make it a smartphone worth showing off. Its Precise Laser Cutting, On-screen Security, and its Dynamic AMOLED screen ensure that this smartphone is easy on your eyes while also enhancing your user experience.', '', 'Slim and Light\r\nThis mobile phone features an Ultr...', '', 'Handset, Adapter(9V/2A), USB Type C Cable, SIM Card Tool, Screen Protect Film, Important Info Booklet with Warranty Card, Quick Guide\r\n', '4GB', 'RMX3197', 'C25s', 'Watery Blue\r\n', 'Smartphones', 'Mobile', '2021-07-29 20:35:48'),
(12, 'in-2b.jpeg', 'Micromax IN 2B (Black, 64 GB)  (4 GB RAM)', '10999', '12999', '64GB', '4 GB RAM | 64 GB ROM | Expandable Upto 256 GB\r\n16.56 cm (6.52 inch) HD+ Display\r\n13MP + 2MP | 5MP Front Camera\r\n5000 mAh Battery\r\nUnisoc T610 Octa Core Processor', 'Get ready to explore the next generation of powerful computing and mobile photography with the Samsung Galaxy S10 Plus. It comes with an Intelligent Camera that automatically optimizes its settings to give you picture-perfect photos. That\'s not all, the Samsung S10 Plus has the Infinity-O Display and a seamless design that make this smartphone a true masterpiece.\r\n', 'No Notch, No Distractions - Design\r\nThe Samsung S10 Plus is designed to give you a smartphone experience like never before. How? It has no notch and no distractions, which make it a smartphone worth showing off. Its Precise Laser Cutting, On-screen Security, and its Dynamic AMOLED screen ensure that this smartphone is easy on your eyes while also enhancing your user experience.', '', 'Slim and Light\r\nThis mobile phone features an Ultr...', '', 'Handset, Charger, Data Cable, SIM Tool Ejector, Screen Guard, TPU Case, User Manual\r\n', '6GB', 'E7544', 'IN 2B\r\n', 'Black', 'Smartphones', 'Mobile', '2021-08-01 07:35:43'),
(13, 'm3-pro.jpeg', 'POCO M3 Pro 5G (Power Black, 64 GB)  (4 GB RAM)#JustHere\r\n', '13999', '18999', '64GB', '4 GB RAM | 64 GB ROM | Expandable Upto 1 TB\r\n16.51 cm (6.5 inch) Full HD+ Display\r\n48MP + 2MP + 2MP | 8MP Front Camera\r\n5000 mAh Lithium-ion Polymer Battery\r\nMediaTek Dimensity 700 Processor', 'The POCO M3 Pro 5G features the MediaTek Dimensity 700 processor to impress you with its powerful performance. Its Switchblade design and elegant 3D curved back (with a glossy finish) so that you can enjoy its innovative features and its stylish design as well. And, its 48 MP triple cameras enable you to take stunning pictures of people and places around you.\r\n', '\r\nFast and Powerful\r\nThe POCO M3 Pro 5G provides fast performance along with low latency and quick connection. This way, you can enjoy speed and power with this mobile phone.', '', 'Impressive Performance\r\nThis mobile phone features the MediaTek Dimensity 700 processor and comes with the UFS 2.2 WriteBooster and impressive RAM to ensure that you can enjoy top-notch performance.', '', 'Handset, Power Adaptor, USB Type-C Cable, SIM Ejector Tool, Protective Case, Quick Start Guide and Warranty Card\r\n', '4GB', 'MZB08QYIN', 'M3 Pro 5G\r\n', 'Black', 'Smartphones', 'Mobile', '2021-08-01 07:36:19'),
(14, 'motorola-g9.jpeg', 'MOTOROLA G9 Power (Electric Violet, 64 GB)  (4 GB RAM)\r\n', '17999', '19999', '64GB', '4 GB RAM | 64 GB ROM | Expandable Upto 512 GB\r\n17.22 cm (6.78 inch) HD+ Display\r\n64MP + 2MP + 2MP | 16MP Front Camera\r\n6000 mAh Li-Polymer Battery\r\nQualcomm Snapdragon 662 Processor\r\n20 W Fast Charging\r\nStock Android Experience', '\r\nMassive 6000 mAh Battery\r\nIf you’re looking for a smartphone that will help you play games, capture amazing photos, and enjoy a lag-free experience, then the moto g9 power is for you. With this smartphone, you can easily capture life\'s best moments and also store them conveniently as it comes with a 64 MP triple camera system and an internal storage space of up to 64 GB (expandable up to 512 GB via a microSD card). What’s more, this smartphone also offers a long-lasting battery backup as it comes with a 6000 mAh battery.\r\n\r\n', 'Massive 6000 mAh Battery\r\nWith this smartphone in your hand, you can video chat with your friends, play games, watch movies, and do more for long hours without worrying about a low-battery notification, thanks to its 6000 mAh battery.', '', 'Stunning 64 MP Triple Camera System\r\nThe moto g9 power smartphone includes a 64 MP triple camera setup, with Quad Pixel technology, which ensures that you can capture stunning, high-resolution, and sharper images every single time.', '', 'Handset, Charger, USB Cable, SIM Tool, Protective Cover, Guides\r\n', '4GB', 'PALR0016IN', 'G9 Power\r\n', 'Watery Blue\r\n', 'Smartphones', 'Mobile', '2021-08-01 07:41:53'),
(15, 'apple-iphone.jpeg', 'APPLE iPhone 12 (Blue, 128 GB)\r\n', '82999', '90000', '128GB', '128 GB ROM\r\n15.49 cm (6.1 inch) Super Retina XDR Display\r\n12MP + 12MP | 12MP Front Camera\r\nA14 Bionic Chip with Next Generation Neural Engine Processor\r\nCeramic Shield\r\nIP68 Water Resistance\r\nAll Screen OLED Display', '\r\nMassive 6000 mAh Battery\r\nIf you’re looking for a smartphone that will help you play games, capture amazing photos, and enjoy a lag-free experience, then the moto g9 power is for you. With this smartphone, you can easily capture life\'s best moments and also store them conveniently as it comes with a 64 MP triple camera system and an internal storage space of up to 64 GB (expandable up to 512 GB via a microSD card). What’s more, this smartphone also offers a long-lasting battery backup as it comes with a 6000 mAh battery.\r\n\r\n', 'Massive 6000 mAh Battery\r\nWith this smartphone in your hand, you can video chat with your friends, play games, watch movies, and do more for long hours without worrying about a low-battery notification, thanks to its 6000 mAh battery.', '', 'Stunning 64 MP Triple Camera System\r\nThe moto g9 power smartphone includes a 64 MP triple camera setup, with Quad Pixel technology, which ensures that you can capture stunning, high-resolution, and sharper images every single time.', '', 'iPhone, USB-C to Lightning Cable, Documentation\r\n', '8GB', 'MGJE3HN/A\r\n', 'iPhone 12\r\n', 'Watery Blue\r\n', 'Smartphones', 'Mobile', '2021-08-01 08:20:08');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `uid` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `password` varchar(30) NOT NULL,
  `role` int(10) NOT NULL DEFAULT 0,
  `gender` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`uid`, `name`, `email`, `mobile`, `password`, `role`, `gender`) VALUES
(1, 'Admin', 'admin@gmail.com', '7894561230', '1234', 1, 'Male'),
(2, 'Saikumar', 'sai@gmail.com', '7894561230', '1234', 0, 'Male'),
(3, 'sathish', 'sathish@gmail.com', '9859685743', '1234', 0, 'Male'),
(4, 'rakesh', 'rakesh@gmail.com', '7859641250', 'rak1234', 0, 'Male'),
(5, 'venky', 'venky@gmail.com', '9878987485', '1234', 0, 'Male'),
(6, 'sai pilli', 'saipilli@gmail.com', '7418529630', 'sai1234', 0, 'Male');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `address`
--
ALTER TABLE `address`
  ADD PRIMARY KEY (`address_id`),
  ADD KEY `uid` (`uid`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`uid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `address`
--
ALTER TABLE `address`
  MODIFY `address_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `address`
--
ALTER TABLE `address`
  ADD CONSTRAINT `address_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `users` (`uid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
