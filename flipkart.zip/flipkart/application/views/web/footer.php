<footer>
    <div class="container-fluid">
        <div class="row footer-row">
            <div class="col-sm-2">
                <div class="footer-heading">
                    <p>ABOUT</p>
                </div>
                <div class="footer-list">
                    <a href="#">Contact Us</a>
                    <a href="#">About Us</a>
                    <a href="#">Careers</a>
                    <a href="#">Flipkart Stories</a>
                    <a href="#">Press</a>
                    <a href="#">Flipkart Wholesale</a>
                </div>
            </div>
            <div class="col-sm-2">
                <div class="footer-heading">
                    <p>HELP</p>
                </div>
                <div class="footer-list">
                    <a href="#">Payments</a>
                    <a href="#">Shipping</a>
                    <a href="#">Cancellation & Returns</a>
                    <a href="#">FAQ</a>
                    <a href="#">Report Infringement</a>

                </div>
            </div>
            <div class="col-sm-2">
                <div class="footer-heading">
                    <p>POLICY</p>
                </div>
                <div class="footer-list">
                    <a href="#">Return Policy</a>
                    <a href="#">Terms Of Use</a>
                    <a href="#">Security</a>
                    <a href="#">Privacy</a>
                    <a href="#">Sitemap</a>
                    <a href="#">EPR Compliance</a>
                </div>
            </div>
            <div class="col-sm-1">
                <div class="footer-heading">
                    <p>SOCIAL</p>
                </div>
                <div class="footer-list">
                    <a href="#">Facebook</a>
                    <a href="#">Twitter</a>
                    <a href="#">YouTube</a>

                </div>
            </div>
            <div class="col-sm-2">
                <div class="footer-heading">
                    <p>Mail Us</p>
                </div>
                <div class="footer-list">
                    <p>Flipkart Internet Private Limited,
                        Buildings Alyssa, Begonia &
                        Clove Embassy Tech Village,
                        Outer Ring Road, Devarabeesanahalli Village,
                        Bengaluru, 560103,
                        Karnataka, India</p>

                </div>
            </div>

            <div class="col-sm-3">
                <div class="footer-heading">
                    <p>Registered Office Address</p>
                </div>
                <div class="footer-list-address">
                    <p>Flipkart Internet Private Limited,</p>
                    <p>Buildings Alyssa, Begonia &</p>
                    <p>Clove Embassy Tech Village,</p>
                    <p>Outer Ring Road, Devarabeesanahalli Village,</p>
                    <p>Bengaluru, 560103,</p>
                    <p>Karnataka, India</p>
                    <p>CIN : U51109KA2012PTC066107</p>
                    <p> Telephone:<span> 1800 202 9898</span></p>
                </div>
            </div>
        </div>
        <hr>
        <div class="row sub-footer">
            <div class="col-sm-2">
                <p>Sell On Flipkart</p>
            </div>
            <div class="col-sm-1">
                <p>Advertise</p>
            </div>
            <div class="col-sm-1">
                <p>Gift Cards</p>
            </div>
            <div class="col-sm-2">
                <p>Help Center</p>
            </div>
            <div class="col-sm-2">
                <p>© 2007-2021 Flipkart.com</p>
            </div>
            <div class="col-sm-4">
                <img src="<?=base_url('/images/header/payment.svg')?>" alt="payments" class="img">
            </div>
        </div>
    </div>
</footer>
</body>

</html>