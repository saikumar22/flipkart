<style>
.page {
    margin-top: 90px;
}

nav .navbar-header a {
    /* font-family: 'Raleway', sans-serif; */
    letter-spacing: 1px;
}

nav .navbar-header a,
ul li a {
    color: #fff;

}

nav .navbar-header button .fa {
    color: #fff;
    border: 1px solid #fff;
    border-radius: 5px;
    padding: 4px 10px;
    font-size: 1.5em;
    position: absolute;
    top: -0.5px;
    left: -30px;
}

.glyphicon-search {
    color: #2874f0;
}

form {
    position: relative;
    top: 10px;
}

.menu {
    border-bottom: 1px solid rgba(0, 0, 0, 0.1);
}

section {
    position: relative;
    background-color: white;
}

section .container-fluid .thumbnail .caption .buttons {
    margin: 1px;
}

section .desc h5 .glyphicon {
    color: #5cb85c;
}

section .desc .breadcrumb {
    padding-left: 0;
}

section .desc button:hover {
    background-color: #fff;
    border: 1px solid #2874f0;
    color: #2874f0;
}

.btn-default {
    width: 70px;
    border: 1px dashed #337ab7;
    color: #337ab7;
}
</style>
<section>
    <div class="container-fluid display">
        <div class="row page">
      <?php foreach ($products as $products => $rg):?>
            <div class="col-sm-5">
                <div class="thumbnail">
                <img style="width:30%" class="img" src="<?php echo base_url('products/'.$rg->image);?>">
                    <div class="caption">
                        <div class="row buttons">
                            <button class="btn  col-sm-4 col-sm-offset-2 btn-lg"
                                style="background-color:#ff9f00; color:#fff;font-size:1em;"><span
                                    class="glyphicon glyphicon-shopping-cart"></span>&nbsp;ADD TO CART</button>

                            <button class="btn col-sm-4 col-sm-offset-1 btn-lg"
                                style="background-color:#fb641b; color:#fff;font-size:1em;"><i class="fa fa-bolt"
                                    style="font-size:1.2em;"></i> BUY NOW</button>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Product Description -->
            <div class="col-sm-7 desc">
                <div>
                    <ol class="breadcrumb col-sm-12" style="background-color:transparent;">
                        <li><a href="<?=base_url('admin/index')?>">Home</a></li>
                        <li><a href="<?=base_url('admin/view')?>">Mobiles</a></li>
                        <li class="active"><?=$rg->name?></li>
                    </ol>
                    <h4><?=$rg->name?></h4>
                    <div class="row">
                        <div class="col-sm-1">
                            <span class="label label-success">4.6 <span class="glyphicon glyphicon-star"></span></span>
                        </div>
                        <div class="col-sm-5">
                            <strong>2,421 Ratings & Reviews</strong>
                        </div>
                    </div>
                    <div class="row">
                        <h3> ₹ <?=$rg->price?></h3>
                        <?=$rg->aprice?>
                    </div>
                    <div>
                        <h5><span class="glyphicon glyphicon-calendar"></span> EMIs from <strong>Rs 3,070/month
                            </strong><a href="">View Plans <i class="fa fa-chevron-right"></i></a></h5>

                        <h5><span class="glyphicon glyphicon-tag"></span><strong> Bank Offer</strong> 5% Instant
                            Discount on Visa Cards for First 3 Online Payments. <a href="">T&C</a></h5>

                        <h5><span class="glyphicon glyphicon-tag"></span><strong> Bank Offer</strong> Extra 5% off*
                            with Axis Bank Buzz Credit Card. <a href="">T&C</a></h5>
                        <h5>Brand Warranty of 1 Year <a href="">Know More</a></h5>
                    </div>

                    <div class="row" style="padding: 10px;">
                        <div class="col-sm-4">
                            <strong>Color</strong>
                            <button class="btn btn-default" style="width:50px;"><img
                                    src="https://cdn.mobilephonesdirect.co.uk/images/handsets/480/apple/apple-iphone-x-silver.png"
                                    class="img-responsive" alt=""></button>
                            <button class="btn btn-default" style="width:50px;"><img
                                    src="https://cdn.mobilephonesdirect.co.uk/images/handsets/apple/apple-iphone-x-space-grey.png"
                                    class="img-responsive" alt=""></button>
                        </div>
                        <br>
                        <div class="col-sm-5">
                            <strong>Storage</strong>
                            <button class="btn btn-default"><?= $rg->storage;?></button>
                            <button class="btn btn-default">256GB</button>
                        </div>
                        <br> <br> <br>
                        <div class="col-sm-9">
                            <strong>RAM</strong>
                            <button class="btn btn-default"><?= $rg->ram;?></button>
                            <button class="btn btn-default">8GB</button>
                        </div>
                    </div>

                    <div id="highlights">
                        <strong class="col-xs-2">Highlights</strong>
                        <ul class="col-xs-6">
                            <li> <?= $rg->highlights;?></li>
                        </ul>
                    </div>

                </div>
                <br><br>

                <div class="container col-xs-12" style="margin-top:50px;">
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <div class="col-sm-12">
                                <h3>PRODUCT DESCRIPTION</h3>
                                <p><?=$rg->description;?></p>

                            </div>

                        </div>
                        <hr>
                        <div class="panel-body">
                            <div class="col-sm-12">
                                <div class="col-sm-8">
                                    <p><?=$rg->des_1;?></p>
                                </div>
                                <div class="col-sm-4">
                                    <img src="https://rukminim1.flixcart.com/image/200/200/j9338nk0/mobile/g/u/h/apple-iphone-8-plus-mq8f2hn-a-original-imaeyym9hdbqaxhp.jpeg?q=90"
                                        class="img-responsive" alt="">
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="panel-body">
                            <div class="col-sm-12">
                                <div class="col-sm-4">
                                    <img src="https://rukminim1.flixcart.com/image/200/200/j9338nk0/mobile/g/u/h/apple-iphone-8-plus-mq8f2hn-a-original-imaeyynjb4vxrdgd.jpeg?q=90"
                                        class="img-responsive" alt="">
                                </div>
                                <div class="col-sm-8">
                                    <p><?=$rg->des_2;?></p>
                                </div>
                            </div>
                        </div>
                        <div class="panel-footer">
                            <h4><a href="" style="text-decoration:none;">View all features</a></h4>
                        </div>
                    </div>

                    <!-- Specifications -->
                    <div class="panel panel-default" id="specifications">
                        <div class="panel-heading" style="background-color:#fff;">
                            <h3>Specifications</h3>
                        </div>

                        <div class="panel-body">

                            <h4>General</h4>

                            <table class="table table-default">
                                <tbody>
                                    <tr>
                                        <td class="col-sm-4">In The Box</td>
                                        <td class="col-sm-8">
                                            <?=$rg->general;?>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td class="col-sm-4">Model Number</td>
                                        <td class="col-sm-8">
                                            <?=$rg->modelnumber;?></td>
                                    </tr>

                                    <tr>
                                        <td class="col-sm-4">Model Name</td>
                                        <td class="col-sm-8">
                                            <?=$rg->modelname;?></td>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="col-sm-4">Color</td>
                                        <td class="col-sm-8"><?=$rg->color;?></td>
                                    </tr>

                                    <tr>
                                        <td class="col-sm-4">Browse Type</td>
                                        <td class="col-sm-8"><?=$rg->browsetype;?></td>
                                    </tr>

                                </tbody>

                            </table>
                        </div>

                        <div class="panel-footer">
                            <h4><a href="">Read More</a></h4>
                        </div>
                    </div>

                </div>
                <?php endforeach?>
               
            </div>
        </div>
</section>