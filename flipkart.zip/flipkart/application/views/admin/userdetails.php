<div class="userdetails">
    <div class="container" id="userdetails">
        <div class="row" id="display">
            <div class="col-md">
                <table class="table table-striped">
                    <div>
                        <h4><b>Users Details</b></h4>
                    </div>
                    <thead class="theader" id="view">
                        <tr>
                            <th>ID</th>
                            <th>NAME</th>
                            <th>GENDER</th>
                            <th>EMAIL</th>
                            <th>PASSWORD</th>
                            <th>MOBILE</th>
                        </tr>
                    </thead>
                    <tbody>
                    
                        <?php	$i = 0;
                         foreach ($users as $user):
                            $i++;?>
                        <tr>
                            <td><?= $i ?></td>
                            <td><?php echo $user->name;?></td>
                            <td><?php echo $user->gender;?></td>
                            <td><?php echo $user->email;?></td>
                            <td>*****</td>
                            <td><?php echo $user->mobile;?></td>

                            <!-- <td><?php
                                $uid = $user->uid;
                                $row = $this->db->where("uid",$uid)->get("address")->result();
                                    echo ($row[0]->address);
                                ?></td> -->
                        </tr>
                        <?php endforeach; $i++ ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>