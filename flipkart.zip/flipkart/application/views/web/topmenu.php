<style>
</style>
<section>
    <div class="container-fluid" id="homenav" style="margin-top: 80px">
        <div class="row">
            <div class="col-sm-1 col-xs-12 col-md-1" style="margin-left: 40px;"></div>
            <div class="col-sm-1 col-xs-12 col-md-1 ">
                <a href="<?= base_url('home/topoffers');?>">
                    <img src="<?=base_url('/images/header/navimg1.png')?>" class="img" alt="img">
                    <p>Top Offers</p>
                </a>
            </div>
            <div class="col-sm-1 col-xs-12 col-md-1">
                <a href=""><img src="<?=base_url('/images/header/navimg2.png')?>" class="img" alt="img">
                    <p>Grocery</p>
                </a>
            </div>
            <div class="col-sm-1 col-xs-12 col-md-1">
                <a href=""><img src="<?=base_url('/images/header/navimg3.png')?>" class="img" alt="img">
                    <p>Mobiles</p>
                </a>
            </div>
            <div class="col-sm-1 col-xs-12 col-md-1">
                <li class="upper-links dropdown"><a class="links more-button" href=""><img
                            src="<?=base_url('/images/header/navimg4.png')?>" class="img" alt="img">
                        <p style="font-size: 15px;">Fashion</p></i>
                    </a>
                    <ul class="dropdown-menu">
                        <li class="profile-li sidenav"><button class="dropdown-btn profile-links"
                                href="<?= base_url();?>"> Men's Top
                                Wear <i class="fa fa-caret-down"></i></button>

                            <div class="dropdown-container">
                                <a href="<?=base_url("home/topfashion")?>">All</a>
                                <a href="#">Men's T-Shirts</a>
                                <a href="#">Men's Casual Shirts</a>
                                <a href="#">Men's Formal Shirts</a>
                                <a href="#">Men's Kurtas</a>
                                <a href="#">Men's Ethnic Sets</a>
                                <a href="#">Men's Blazers</a>
                                <a href="#">Men's Raincoat</a>
                                <a href="#">Men's Windcheaters</a>
                                <a href="#">Men's Suit</a>
                                <a href="#">Men's Fabrics
                                </a>

                            </div>
                        </li>
                        <!-- <li class='has-submenu'><a class='prett' href='Dropdown 1' title='Dropdown 1'> Men's Top
                                Wear</a>
                            <ul class='submenu'>
                                <li><a href="#" title="Sub Menu">Sub Menu</a></li>
                                <li><a href="#" title="Sub Menu">Sub Menu 2</a></li>
                                <li><a href="#" title="Sub Menu">Sub Menu 3</a></li>
                            </ul>
                        </li> -->
                        <li class="profile-li"><a class="profile-links" href="<?= base_url();?>">Men's Bottom Wear <i
                                    class="fa fa-caret-down"></i></a>
                        </li>
                        <li class="profile-li"><a class="profile-links" href="<?= base_url();?>">Women Ethnic</a>
                        </li>
                        <li class="profile-li"><a class="profile-links" href="<?= base_url();?>">Women Western</a>
                        </li>
                        <li class="profile-li"><a class="profile-links" href="">Men Footwear</a>
                        </li>
                        <li class="profile-li"><a class="profile-links" href="">Women Footwear</a>
                        </li>
                        <li class="profile-li"><a class="profile-links" href="">Watches and Accessories</a>
                        </li>
                        <li class="profile-li"><a class="profile-links" href="">Bags, Suitcases & Luggage</a>
                        </li>
                        <li class="profile-li"><a class="profile-links" href="">Kids</a>
                        </li>
                        <li class="profile-li"><a class="profile-links" href="">Essentials</a>
                        </li>
                        <li class="profile-li"><a class="profile-links" href="">Winter</a>
                        </li>
                    </ul>

                </li>






                <!-- <a href="<?=base_url('home/topfashion')?>"><img src="<?=base_url('/images/header/navimg4.png')?>" class="img" alt="img">
                    <p>Fashion</p>
                </a> -->
            </div>
            <div class="col-sm-1 col-xs-12 col-md-1">
                <a href=""><img src="<?=base_url('/images/header/navimg5.png')?>" class="img" alt="img">
                    <p>Electronics</p>
                </a>
            </div>
            <div class="col-sm-1 col-xs-12 col-md-1">
                <a href=""><img src="<?=base_url('/images/header/navimg6.jpg')?>" class="img" alt="img">
                    <p>Home</p>
                </a>
            </div>
            <div class="col-sm-1 col-xs-12 col-md-1">
                <a href=""><img src="<?=base_url('/images/header/navimg7.png')?>" class="img" alt="img">
                    <p>Appliances</p>
                </a>
            </div>
            <div class="col-sm-1 col-xs-12 col-md-1">
                <a href=""><img src="<?=base_url('/images/header/navimg8.png')?>" class="img" alt="img">
                    <p>Travel</p>
                </a>
            </div>
            <div class="col-sm-2 col-xs-2 col-md-2">
                <a href=""><img src="<?=base_url('/images/header/navimg9.png')?>" class="img" alt="img">
                    <p>Beauty, Toys & More</p>
                </a>
            </div>
            <div class="col-sm-1 col-xs-12 col-md-1 "></div>
        </div>
    </div>
</section>