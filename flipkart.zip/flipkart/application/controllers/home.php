<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class home extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->helper('url');
        $this->load->model('homeModel');
        $this->load->library(array('form_validation','session'));
    }

    public function  index(){
        $this->load->view("web/header");
        $this->load->view("web/navbar");
        $this->load->view("web/topmenu");
        $data['products'] =$this->db->get("products")->result();
        $this->load->view("home",$data);
        $this->load->view("web/footer");
    }

    //---------------  register ---
    public function signup(){
        $this->form_validation->set_rules('name', 'name', 'required');
        $this->form_validation->set_rules('email', 'email', 'required');
        $this->form_validation->set_rules('mobile', 'mobile', 'required');
        $this->form_validation->set_rules('password', 'password', 'required');
        $data = array(
            'name' => $this->input->post('name'),
            'email' => $this->input->post('email'),
            'mobile' => $this->input->post('mobile'),
            'password' =>$this->input->post('password')
        );
        $check = $this->db->insert("users",$data);
        if($check != false){
        $users = array(
        'uid' => $check,
        'email' => $this->input->post('email'),
        'name' => $this->input->post('name')
        );
       
        echo '<script type="text/javascript">'; 
		echo 'alert("Register success");'; 
		echo 'window.location.href = "../home";';
		echo '</script>';
    }else{
        echo '<script type="text/javascript">'; 
		echo 'alert("Please check your details");'; 
		echo 'window.location.href = "../home";';
		echo '</script>';
    }
		// $this->session->set_flashdata('status','Register success');
        // redirect(base_url('home')); 
    }
//--------------- login -----
    public function signin(){
        if($this->input->post("submit")){
            $result=$this->db->where([
                "email"=>$this->input->post("email"),
            "password"=>$this->input->post("password")])->get("users")->row();
            $user = array(
                'uid' => $result->uid,
                'email' => $result->email,
                'name' => $result->name,
                'mobile' => $result->mobile
                );
            $this->session->set_userdata($user);
            $_SESSION["name"]=$user["name"];
            $_SESSION["uid"]=$user["uid"];
            if($result->role==1){
                redirect(base_url("admin/index")); 
            }
            else{
                redirect(base_url("home/index")); 
            }
        }
    }

    public function mobiles(){
        $this->load->view("web/header");
        $this->load->view("web/navbar");
        $this->load->view("viewall/mobiles");
        $this->load->view("web/footer");
    }

    public function mens(){
        $this->load->view("web/header");
        $this->load->view("web/navbar");
        $this->load->view("viewall/mens");
        $this->load->view("web/footer");
    }
    public function womens(){
        $this->load->view("web/header");
        $this->load->view("web/navbar");
        $this->load->view("viewall/womens");
        $this->load->view("web/footer");
    }

    public function laptops(){
        $this->load->view("web/header");
        $this->load->view("web/navbar");
        $this->load->view("viewall/loptops");
        $this->load->view("web/footer");
    }
    public function best_deals(){
        $this->load->view("web/header");
        $this->load->view("web/navbar");
        $this->load->view("viewall/bestdeals");
        $this->load->view("web/footer");
    }

    public function headphones(){
        $this->load->view("web/header");
        $this->load->view("web/navbar");
        $this->load->view("viewall/headphones");
        $this->load->view("web/footer");
    }
    public function topoffers(){
        $this->load->view("web/header");
        $this->load->view("web/navbar");
        $this->load->view("top-products/topoffers");
        $this->load->view("web/footer");
    }
    public function prebook(){
        $this->load->view("web/header");
        $this->load->view("web/navbar");
        $this->load->view("prebook/topcard");
        $this->load->view("web/footer");
    }

    public function profile(){
        if($this->session->uid)
        {
            $this->load->view("web/header");
            $this->load->view("web/navbar");
            $this->load->view("web/sideprofile");
            $data['users'] =$this->db->where("uid",$_SESSION['uid'])->get("users")->result();
            $this->load->view("profile",$data);
            $this->load->view("web/footer"); 
        }
        else{
            $this->load->view("forms/register");
        }
    }

    public function personalinfoupdate($uid){
        $data=[
            'name'=>$this->input->post('name'),
            'gender'=>$this->input->post('gender'),
            'email'=>$this->input->post('email'),
            'mobile'=>$this->input->post('mobile')
        ];
        $u = $this->db->where('uid',$uid)->update("users",$data);
		$this->session->set_flashdata('status','Profile Update Successfully');
        redirect(base_url('home/profile/'.$uid));
    }

    public function address(){
        $this->load->view("web/header");
        $this->load->view("web/navbar");
        $this->load->view("web/sideprofile");
        $data['address'] =$this->db->where("uid",$_SESSION['uid'])->get("address")->result();
        $this->load->view("address",$data);
        $this->load->view("web/footer"); 
    }

    public function addressadd(){
        $data=[
            'uid'=>$this->session->uid,
            'name'=>$this->input->post('name'),
            'mobile'=>$this->input->post('mobile'),
            'pincode'=>$this->input->post('pincode'),
            'locality'=>$this->input->post('locality'),
            'address'=>$this->input->post('address'),
            'city'=>$this->input->post('city'),
            'state'=>$this->input->post('state'),
            'landmark'=>$this->input->post('landmark'),
            'type'=>$this->input->post('type'),
            'alternate'=>$this->input->post('alternate')
        ];
        $result= $this->db->where('uid',$this->session->uid)->insert("address",$data);
        if(!$result)
            redirect(base_url());
        else
            redirect('home/address');
    }

    public function addressdelete($address_id){
        $delete= $this->homeModel->delete($address_id);
        if ($delete) {
            redirect(base_url("home/address"));   
        }else{
            echo "unable to delete";
        }
    }
    public function Product_Details($pid){
        $this->load->view("web/header");
        $this->load->view("web/navbar");
        $data['products'] =$this->db->where('pid',$pid)->get("products")->result();
        $this->load->view("product_details",$data);
        $this->load->view("web/footer"); 
    }

    public function productview(){
        $this->load->view("web/header");
        $this->load->view("web/navbar");
        $this->load->view("product-view");
        $this->load->view("web/footer"); 
    }

    public function cart(){
        if($this->session->uid){
            $this->load->view("web/header");
            $this->load->view("web/navbar");
            $result['cart'] = $this->db->where("uid",$this->session->uid)->get("cart")->result();
            $this->load->view('cart',$result);
            $this->load->view("web/footer"); 
        }
        else{
            redirect(base_url("home"));
        }
    }

   public function save_cart(){
    if($this->session->uid){
            $this->load->view("web/header");
            $this->load->view("web/navbar");
            $data=array();
            $pid= $this->input->post('pid');
            $results=$this->homeModel->get_product_by_id($pid);
            
            $data['uid']=$this->session->uid;
            $data['pid']= $results->pid;
            $data['price']=$results->price;
            $data['total']=$results->price;
            $data['name']=$results->name;

            $this->db->insert('cart',$data);
            redirect(base_url("home/cart"));
            $this->load->view("web/footer"); 
        }
        else{
            redirect(base_url("home"));
        }
    }
    public function update_cart(){
        $cid = $_POST['cid'];
        $price = $_POST['price'];
        $quantity = $_POST['quantity'];
        $total = $price * $_POST['quantity'];
    
        $data = array(
            
            'price' => $price,
            'quantity' => $quantity,
            'total' => $total
            );
        $this->db->where('cid',$cid)->update("cart",$data);
        // echo $data['total'];
        redirect(base_url("home/cart"));


    }

    public function remove($cid){
        $delete= $this->homeModel->removetocart($cid);
            if ($delete) {
                redirect(base_url("home/cart")); 
                echo "success";      
            }else{
                echo "unable to delete";
        }
    }

    public function products_views(){
        $this->load->view("web/header");
        $this->load->view("web/navbar");
        $this->load->view("web/dressfilters");
        $this->load->view("productlist");
        $this->load->view("web/footer");  
    }
    public function topfashion(){
        $this->load->view("web/header");
        $this->load->view("web/navbar");
        $this->load->view("web/dressfilters");
        $this->load->view("top-products/topfashion");
        $this->load->view("web/footer");  
    }
    public function mobile_views(){
        $this->load->view("web/header");
        $this->load->view("web/navbar");
        $this->load->view("web/mobilefilters");
        $this->load->view("mobilelist");
        $this->load->view("web/footer");  
    }

    public function big_sale(){
        $this->load->view("web/header");
        $this->load->view("web/navbar");
        $this->load->view("prebook/siderview");
        $this->load->view("web/footer");  
    }

    public function logout(){
        session_destroy();
        redirect(base_url());
    }   
}