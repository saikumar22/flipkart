<style>
#flipkart-navbar {
    background-color: #2874f0;
    color: #FFFFFF;
}

.row1 {
    padding-bottom: 20px;
    margin-top: 20px;
}

.flipkart-navbar-input {
    padding: 8px 16px;
    border-radius: 2px 0 0 2px;
    border: 0 none;
    outline: 0 none;
    font-size: 15px;
}

.flipkart-navbar-button {
    background-color: #ffe11b;
    border: 1px solid #ffe11b;
    border-radius: 0 2px 2px 0;
    color: #565656;
    padding: 10px 0;
    height: 43px;
    cursor: pointer;
}

.dropdown {
    position: relative;
    display: inline-block;
    margin-bottom: 0px;
}

.dropdown:hover .dropdown-menu {
    display: block;
}

.dropdown .dropdown-menu {
    position: absolute;
    top: 100%;
    display: none;
    background-color: #fff;
    color: #333;
    left: 0px;
    border: 0;
    border-radius: 0;
    box-shadow: 0 4px 8px -3px #555454;
    margin: 0;
    padding: 0px;
}

.links {
    color: #fff;
    text-decoration: none;
}

.links:hover {
    color: #fff;
    text-decoration: none;
}

.profile-links {
    font-size: 12px;
    font-family: 'Roboto', sans-serif;
    border-bottom: 1px solid #e9e9e9;
    box-sizing: border-box;
    display: block;
    padding: 0 11px;
    line-height: 23px;
}

.profile-li {
    padding-top: 2px;
}

.largenav {
    display: none;
}

.smallnav {
    display: block;
}

.smallsearch {
    margin-left: 15px;
    margin-top: 15px;
}


@media screen and (min-width: 768px) {
    .largenav {
        display: block;
    }

    .smallnav {
        display: none;
    }

    .smallsearch {
        margin: 0px;
    }
}

.flipkart {
    color: white;
}

.cart {
    color: white;
    font-weight: bold;
    font-size: 16px;
    font: Arial, sans-serif;
    list-style: none;
}
.cart:hover{
    color: white;
    text-decoration: none;
}


.login-button {
    border: none;
    width: 120px;
    font-weight: bold;
    height: 30px;
    font-size: 16px;
}

.col-sm-4 {
    padding-left: 20px;
}

.more-button {
    color: white;
    font-size: 16px;
    font-weight: bold;
}

/*-------------login  */

.login .col-sm-5 {
    background-color: #2874f0;
    color: white;
    margin-left: 0px;
    margin-top: 0px
}

.login .loginrow .col-sm-6 {
    padding: 20px;

}

.login .footer {
    padding: 20px;
    margin-top: 10px;
}

.login .user-id .btn-lg {
    background: #fb641b;
    border-radius: 2px;
    color: white;
    text-align: center;
    font-weight: 500;
    font-size: 15px;
    outline: none;
    transition: 0.5s;
    margin-top: none;
}

.login .inline-text-footer {
    margin-bottom: 100px;
    margin-top: 50px;
}

.login .user-id {
    text-align: center;
}

.login .close {
    color: white;
}

.login {
    padding: 30px;
}

.login .col-xs-6 {
    float: center;
}

.form-label {
    margin-top: 10px;
}

.upper-links li {
    padding: 5px;
}
</style>

<div id="flipkart-navbar" class="navbar navbar-fixed-top">
    <div class="container">
        <div class="row row1">
            <div class="col-sm-1">
                <div class="header-left navbar-brand">
                    <a href="<?=base_url('home/index')?>">Flipkart</a>
                    <div class="header-left-p" style="margin-left: -20px;">
                        <p><a href="#">Explore</a> <span>Plus <img src="<?=base_url('/images/header/small-logo.png')?>"
                                    alt="img" style="width: 10px; margin-top: -4px;"></span></p>
                    </div>
                    &nbsp;
                </div>
            </div>
            <div class="flipkart-navbar-search smallsearch col-sm-8  col-xs-12 col-lg-7">
                <input type="text" class="flipkart-navbar-input col-xs-8" style="color:black"
                    placeholder="Search for products, brand and more" name="">
                <button class="btn btn-default" type="submit" style="margin-left: -4px; height:37px"><i
                        class="glyphicon glyphicon-search"></i>
                </button>
            </div>
            &nbsp;
            <div class="col-sm-4" style="margin-top: -10px;">
                <?php if(isset($this->session->uid)){?>
                <li class="upper-links dropdown"><a class="links login-button"> <?=$this->session->name?></a>
                    <ul class="dropdown-menu">
                        <li class="profile-li"><a class="profile-links" href="<?= base_url("home/profile");?>">My
                                Profile</a></li>
                        <li class="profile-li"><a class="profile-links" href="<?= base_url();?>">Orders</a></li>
                        <li class="profile-li"><a class="profile-links" href="<?= base_url();?>">Flipkart Plus
                                Zone</a>
                        </li>
                        <li class="profile-li"><a class="profile-links" href="<?= base_url();?>">Wishlist</a></li>
                        <li class="profile-li"><a class="profile-links" href="<?= base_url();?>">Rewards</a></li>
                        <li class="profile-li"><a class="profile-links" href="<?= base_url();?>">Gift Cards</a></li>
                        <li class="profile-li"><a class="profile-links" href="<?= base_url("home/logout");?>">Logout</a>
                        </li>
                    </ul>
                    &nbsp; &nbsp; &nbsp; &nbsp;
                </li>
                <?php } 
                    else{?>
                <li class="upper-links dropdown"><button class="links login-button" data-toggle="modal"
                        data-target="#login" style="color: blue; background-color:white;">Login</button>
                    <ul class="dropdown-menu">
                        <li class="profile-li"><a class="profile-links" data-toggle="modal" data-target="#signup"> New
                                customer?
                                <span style="color: blue;">Sign up</span></a></li>
                        <li class="profile-li"><a class="profile-links" href="<?= base_url('home/profile');?>">My
                                Profile</a></li>
                        <li class="profile-li"><a class="profile-links" href="<?= base_url();?>">Flipkart Plus
                                Zone</a>
                        </li>
                        <li class="profile-li"><a class="profile-links" href="<?= base_url();?>">Orders</a></li>
                        <li class="profile-li"><a class="profile-links" href="<?= base_url();?>">Wishlist</a></li>
                        <li class="profile-li"><a class="profile-links" href="<?= base_url();?>">Rewards</a></li>
                        <li class="profile-li"><a class="profile-links" href="<?= base_url();?>">Gift Cards</a></li>
                    </ul>
                    &nbsp; &nbsp; &nbsp; &nbsp;
                </li>
                <?php } ?>
                <li class="upper-links dropdown"><a class="links more-button" href=""> More<span
                            class="glyphicon glyphicon-menu-down btn-sm"></span></i></a>
                    <ul class="dropdown-menu">
                        <li class="profile-li"><a class="profile-links" href="<?= base_url();?>"> Notification
                                Preferences</a></li>
                        <li class="profile-li"><a class="profile-links" href="<?= base_url();?>">Sell on
                                Flipkart</a>
                        </li>
                        <li class="profile-li"><a class="profile-links" href="<?= base_url();?>">24x7 Customer
                                Care</a>
                        </li>
                        <li class="profile-li"><a class="profile-links" href="<?= base_url();?>">Advertise</a></li>
                        <li class="profile-li"><a class="profile-links"
                                href="https://www.flipkart.com/mobile-apps?otracker=ch_vn_mobile_apps">Download App</a>
                        </li>
                    </ul>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </li>

                <a href="<?=base_url("home/cart")?>" class="cart">
                    <svg class="cart-svg" width="16 " height="16 " viewBox="0 0 16 16 ">
                        <path
                            d="M15.32 2.405H4.887C3 2.405 2.46.805 2.46.805L2.257.21C2.208.085 2.083 0 1.946 0H.336C.1 0-.064.24.024.46l.644 1.945L3.11 9.767c.047.137.175.23.32.23h8.418l-.493 1.958H3.768l.002.003c-.017 0-.033-.003-.05-.003-1.06 0-1.92.86-1.92 1.92s.86 1.92 1.92 1.92c.99 0 1.805-.75 1.91-1.712l5.55.076c.12.922.91 1.636 1.867 1.636 1.04 0 1.885-.844 1.885-1.885 0-.866-.584-1.593-1.38-1.814l2.423-8.832c.12-.433-.206-.86-.655-.86 "
                            fill="#fff "></path>
                    </svg> Cart
                </a>
            </div>
        </div>
    </div>
</div>

<div id="login" class="modal fade login" role="dialog">
    <form action="<?= base_url('home/signin')?>" method="POST" enctype="multipart/form-data">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="row loginrow" style="background:white">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <div class="col-sm-5 col-xs-12 loginrow1">
                        <div class="inline-text">
                            <h1>Login</h1>
                            <p>
                                Get access to your Orders,<br />
                                Wishlist and<br />
                                Recomadations
                            </p>
                        </div>
                        <div class="inline-text-footer">
                            <img src="//img1a.flixcart.com/www/linchpin/fk-cp-zion/img/login_img_dec4bf.png" alt="">
                        </div>
                    </div>
                    <div class="col-sm-6 col-xs-12">
                        <div class="col-sm-12 col-xs-12">
                            <label for="exampleFormControlInput1" class="form-label">Email:</label>
                            <input type="email" name="email" class="form-control" required />
                        </div>
                        <div class="col-sm-12 col-xs-12">
                            <label for="exampleFormControlInput1" class="form-label">Password:</label>
                            <input type="password" name="password" class="form-control" required />
                        </div>
                    </div>
                    <!-- <span><a href="#" class="loginlinks1">Forgot?</span></a> -->
                    <div class="user-id button">
                        <input type="submit" class="btn-lg" name="submit" value="Login" />
                    </div>
                    <div class="user-id">
                        <p>OR</p>
                    </div>
                    <div class="user-id button">
                        <input type="reset" class="btn-lg" name="" id="" value="Request OTP" />
                    </div>
                    <div class="row">
                        <div class="footer col-xs-6">
                            <p class="loginlinks"><a data-toggle="modal" data-target="#signup">New to Flipkart? Create
                                    an
                                    account</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>


<!-- sign up -->
<div id="signup" class="modal fade login" role="dialog">
    <form action="<?= base_url('home/signup')?>" method="POST" enctype="multipart/form-data">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="row loginrow" style="background:white">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <div class="col-sm-5 col-xs-12 loginrow1" style="margin-top: 0px; height: 490px">
                        <div class="inline-text">
                            <h1>Looks like you're new here!</h1>
                            <p>
                                Sign up with your mobile<br />
                                number to get started
                            </p>
                        </div>
                        <div class="inline-text-footer">
                            <img src="//img1a.flixcart.com/www/linchpin/fk-cp-zion/img/login_img_dec4bf.png" alt="">
                        </div>
                    </div>
                    <div class="col-sm-6 col-xs-12" style="margin-left:20px">
                        <div class="row">
                            <label for="exampleFormControlInput1" class="form-label">Name:</label>
                            <input type="text " name="name" class="form-control" required />
                        </div>
                        <div class="row">
                            <label for="exampleFormControlInput1" class="form-label">Email:</label>
                            <input type="email " name="email" class="form-control" required />
                        </div>
                        <div class="row">
                            <label for="exampleFormControlInput1" class="form-label">Password:</label>
                            <input type="password " name="password" class="form-control" required />
                        </div>
                        <div class="row">
                            <label for="exampleFormControlInput1" class="form-label">Mobile:</label>
                            <input type="number" name="mobile" class="form-control" required />
                        </div>

                        <div class="row">
                            <p>By continuing, you agree to Flipkart's <a href="">Terms of Use</a> and<a href="#">
                                    Privacy Policy.</p></a>
                        </div>
                        <div class="user-id button">
                            <input type="submit" class="btn-lg" name="signup" value="Sign Up" />
                        </div>

                        <div class="row">
                            <div class="user-id">
                                <p class="footer"> <a data-toggle="modal" data-target="#login"
                                        value="Existing User? Log in">Existing User? Log
                                        in</a></p>
                            </div>
                        </div>
                       
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>